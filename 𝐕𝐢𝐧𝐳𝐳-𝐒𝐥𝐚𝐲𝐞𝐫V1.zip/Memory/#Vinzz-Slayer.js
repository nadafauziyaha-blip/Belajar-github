/* 
Developer Vinzz
Contact : 6285218951518
Telegrm : http://t.me.VinzzOffc_01
*/
require("../Assets/Msbreewc.js")

//pairing custom
global.custompairing = "VINZZJSS"

//setting even
global.welcome = false
global.autoread = false
global.anticall = false

// setting jeda / delay
global.delaypushkontak = 5500
global.delayjpm = 5500

//setting id/gb
global.idgc = "120363420157795662@g.us"
global.linkgc = "https://chat.whatsapp.com/FVI5g3wiZyIIfKPaQZJzj5?mode=r_c"

// setting panel
global.domain = ''// Domain
global.apikey = '' // ptla
global.capikey = '' // ptlc
global.eggsnya = '15' // eggnya
global.location = '1' // lokasinya

// setting panel v2
global.domain2 = '' // Domain
global.apikey2 = '' // ptla
global.capikey2 = '' // ptlc
global.eggsnya2 = '15' // eggnya
global.location2 = '1' // lokasinya

global.subdomain = {
"serverku.biz.id": {
"zone": "4e4feaba70b41ed78295d2dcc090dd3a", 
"apitoken": "oof_QRNdUC4aMQ3xIB8dmkGaZu7rk2J-0P_tN55l"
}, 
"privatserver.my.id": {
"zone": "699bb9eb65046a886399c91daacb1968", 
"apitoken": "CrQMyDn2fhchlGne2ogAw7PvJLsg4x8vasBv__6D"
}, 
"panelwebsite.biz.id": {
"zone": "2d6aab40136299392d66eed44a7b1122", 
"apitoken": "cj17Lzg9otqwkYIVzgL0pcVA4GfcXqePHAOhCqa_"
}, 
"mypanelstore.web.id": {
"zone": "c61c442d70392500611499c5af816532", 
"apitoken": "N_VhWv2ZK6UJxLdCnxMfZx9PtzAdmPGM3HmOjZR4"
}, 
"pteroserver.us.kg": {
"zone": "f693559a94aebc553a68c27a3ffe3b55", 
"apitoken": "qRxwgS3Kl_ziCXti2p4BHbWTvGUYzAuYmVM28ZEp"
}, 
"digitalserver.us.kg": {
"zone": "df13e6e4faa4de9edaeb8e1f05cf1a36", 
"apitoken": "sH60tbg10UH8gpNrlYpf3UMse1CNJ01EKJ69YVqb"
}, 
"shopserver.us.kg": {
"zone": "54ca38e266bfdf2dcdb7f51fd79c2db5", 
"apitoken": "GRe4rg-vhb4c8iSjKCALHJC0LaxkzNPgmmgcDGpm"
}
}

//setting owner
global.owner = [
  "6283804353600", // ganti nomor owner
  "" // nomor owner kedua kalo ada
]
//setting premiun
global.premium = [
  "6283804353600", // ganti nomor premium
  "" // nomor owner kedua kalo ada
]

global.idch1 = "120363346465536093@newsletter"
global.idch2 = "120363414335768761@newsletter"

//setting mess
global.mess = {
   proses: "bug processing in progress...",
   fitur: "⚠️ *Khusus Developer*",
   group: "Khusus Comunity Vinzz 😜",
   privat: "*khusus Comunity vinzz ya adik adik 😂*",
   owner: "⚠️ *Akses Di Tolak*",
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})