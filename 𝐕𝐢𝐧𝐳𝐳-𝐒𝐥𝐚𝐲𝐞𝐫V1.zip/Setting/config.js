/* 
Developer Vinzz
Contact : 6285218951518
Telegrm : http://t.me.VinzzOffc_01
*/
require("../Assets/Msbreewc.js")

global.packname = "VinzzOfficial"
global.botname = "VinzzGoodFrise"
global.owner = "6285218951518"
global.idchannel = "120363389012094856@newsletter" 
global.chvinzz = "https://whatsapp.com/channel/0029Vb8PXM73gvWUGGujbO0V"

//jika ingin setting panel atau domain/ptla/ptlc pergi ke Memory lalu ke #Vinzz-Slayer

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})