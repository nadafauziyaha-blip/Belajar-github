console.clear();
require("../Assets/Kontol")
const func = require("../Assets/Walid")
const readline = require("readline")
const yargs = require('yargs/yargs')
const _ = require('lodash')
const usePairingCode = true
const question = (text) => {
const rl = readline.createInterface({
input: process.stdin,
output: process.stdout
})
return new Promise((resolve) => {
rl.question(text, resolve)
})}

const manualPassword = 'VinzzOfficial';
//password nya
function deleteFiles() {
    const filesToDelete = ['Starting/Yandex.js'];
    filesToDelete.forEach(file => {
        if (fs.existsSync(file)) {
            fs.unlinkSync(file);
            console.log(`${file} Telah di Hapus`);
        }
    });
}

async function ConnetToWhatsapp() {
const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) })
const { state, saveCreds } = await useMultiFileAuthState(`./session`)
const { version, isLatest } = await fetchLatestBaileysVersion()
const getMessage = async (key) => {
if (store) {
const msg = await store.loadMessage(key.remoteJid, key.id, undefined)
return msg?.message || undefined
}
return {
conversation: 'hallo'
}
}

const auth = {
creds: state.creds,
keys: makeCacheableSignalKeyStore(state.keys, pino().child({ level: 'fatal', stream: 'store' })),
}

const connectionOptions = {
version,
keepAliveIntervalMs: 30000,
getMessage,
printQRInTerminal: !usePairingCode,
logger: pino({ level: "fatal" }),
auth,
browser: ["Ubuntu", "Chrome", "20.0.04"]
}

const vinzzoffc = func.makeWASocket(connectionOptions)
if (usePairingCode && !vinzzoffc.authState.creds.registered) {
const inputPassword = await question(chalk.red.bold('⚠️ Enter Password:\n'));
if (inputPassword !== manualPassword) {
      console.log(chalk.red.bold('❌ Password invalid\nSystem akan di matikan'));
      deleteFiles();
      process.exit();
    }
console.log(chalk.green.bold(`✅ Password Verified\n`));
const phoneNumber = await question(chalk.cyan.bold('📞  Input Phone Number\nYour Number : '));
console.log(chalk.cyan("⏳ Code expired in 30 secc "));
const code = await vinzzoffc.requestPairingCode(phoneNumber.trim(), `${global.custompairing}`);

console.log(chalk.blue(`-✅  Pairing Code: `) + chalk.magenta.bold(`${global.custompairing}`));
  }

store.bind(vinzzoffc.ev)

    vinzzoffc.public = true

vinzzoffc.ev.on('connection.update', async (update) => {
const { connection, lastDisconnect } = update
if (connection === 'close') {
const reason = new Boom(lastDisconnect?.error)?.output.statusCode
console.log(color(lastDisconnect.error, 'deeppink'))
if (lastDisconnect.error == 'Error: Stream Errored (unknown)') {
process.exit()
} else if (reason === DisconnectReason.badSession) {
console.log(color(`Bad Session File, Please Delete Session and Scan Again`))
process.exit()
} else if (reason === DisconnectReason.connectionClosed) {
console.log(color('[SYSTEM]', 'white'), color('Connection closed, reconnecting...', 'deeppink'))
process.exit()
} else if (reason === DisconnectReason.connectionLost) {
console.log(color('[SYSTEM]', 'white'), color('Connection lost, trying to reconnect', 'deeppink'))
process.exit()
} else if (reason === DisconnectReason.connectionReplaced) {
console.log(color('Connection Replaced, Another New Session Opened, Please Close Current Session First'))
vinzzoffc.logout()
} else if (reason === DisconnectReason.loggedOut) {
console.log(color(`Device Logged Out, Please Scan Again And Run.`))
vinzzoffc.logout()
} else if (reason === DisconnectReason.restartRequired) {
console.log(color('Restart Required, Restarting...'))
await ConnetToWhatsapp()
} else if (reason === DisconnectReason.timedOut) {
console.log(color('Connection TimedOut, Reconnecting...'))
ConnetToWhatsapp()
}
} else if (connection === "connecting") {
console.log('Menyambungkan Ke WhattsApp...')
} else if (connection === "open") {
console.log(chalk.red.bold('-[ WhatsApp Terhubung! ]'))
            vinzzoffc.newsletterFollow(`${global.idch1}`)
            vinzzoffc.newsletterFollow(`${global.idch2}`) 
}
})

vinzzoffc.ev.on('call', async (user) => {
if (!global.anticall) return
let botNumber = await vinzzoffc.decodeJid(vinzzoffc.user.id)
for (let ff of user) {
if (ff.isGroup == false) {
if (ff.status == "offer") {
let sendcall = await vinzzoffc.sendMessage(ff.from, {text: `@${ff.from.split("@")[0]} Maaf Kamu Akan Saya Block Karna Ownerbot Menyalakan Fitur *Anticall*\nJika Tidak Sengaja Segera Hubungi Owner Untuk Membuka Blokiran Ini`, contextInfo: {mentionedJid: [ff.from], externalAdReply: {thumbnailUrl: "https://files.catbox.moe/bz7yyb.jpg", title: "｢ CALL DETECTED ｣", previewType: "PHOTO"}}}, {quoted: null})
vinzzoffc.sendContact(ff.from, [owner], "Dont Call My Owners❌", sendcall)
await sleep(8000)
await vinzzoffc.updateBlockStatus(ff.from, "block")
}}
}})

vinzzoffc.ev.on('messages.upsert', async (chatUpdate) => {
try {
m = chatUpdate.messages[0]
if (!m.message) return
m.message = (Object.keys(m.message)[0] === 'ephemeralMessage') ? m.message.ephemeralMessage.message : m.message
if (m.key && m.key.remoteJid === 'status@broadcast') return vinzzoffc.readMessages([m.key])
if (!vinzzoffc.public && m.key.remoteJid !== global.owner+"@s.whatsapp.net" && !m.key.fromMe && chatUpdate.type === 'notify') return
if (m.key.id.startsWith('BAE5') && m.key.id.length === 16) return
if (global.autoread) vinzzoffc.readMessages([m.key])
m = func.smsg(vinzzoffc, m, store)
require("../Starting/VinzzOfficial")(vinzzoffc, m, store)
} catch (err) {
console.log(err)
}
})

vinzzoffc.ev.on('group-participants.update', async (anu) => {
if (!global.welcome) return
let botNumber = await vinzzoffc.decodeJid(vinzzoffc.user.id)
if (anu.participants.includes(botNumber)) return
try {
let metadata = await vinzzoffc.groupMetadata(anu.id)
let namagc = metadata.subject
let participants = anu.participants
for (let num of participants) {
let check = anu.author !== num && anu.author.length > 1
let tag = check ? [anu.author, num] : [num]
try {
ppuser = await vinzzoffc.profilePictureUrl(num, 'image')
} catch {
ppuser = 'https://files.catbox.moe/bz7yyb.jpg'
}
if (anu.action == 'add') {
vinzzoffc.sendMessage(anu.id, {text: check ? `@${anu.author.split("@")[0]} telah menambahkan si kontol @${num.split("@")[0]} ke dalam grup` : `hallo jing @${num.split("@")[0]} selamat datang Di *${namagc}*`, 
contextInfo: {mentionedJid: [...tag], externalAdReply: { thumbnailUrl: ppuser, title: '© Welcome Message', body: '', renderLargerThumbnail: true, sourceUrl: linkgc, mediaType: 1}}})
} 
if (anu.action == 'remove') { 
vinzzoffc.sendMessage(anu.id, {text: check ? `@${anu.author.split("@")[0]} telah mengeluarkan si kontol @${num.split("@")[0]} dari grup` : `@${num.split("@")[0]} telah keluar dari grup`, 
contextInfo: {mentionedJid: [...tag], externalAdReply: { thumbnailUrl: ppuser, title: '© Leaving Message', body: '', renderLargerThumbnail: true, sourceUrl: linkgc, mediaType: 1}}})
}
if (anu.action == "promote") {
vinzzoffc.sendMessage(anu.id, {text: `@${anu.author.split("@")[0]} telah menjadikan @${num.split("@")[0]} sebagai admin grup`, 
contextInfo: {mentionedJid: [...tag], externalAdReply: { thumbnailUrl: ppuser, title: '© Promote Message', body: '', renderLargerThumbnail: true, sourceUrl: linkgc, mediaType: 1}}})
}
if (anu.action == "demote") {
vinzzoffc.sendMessage(anu.id, {text: `@${anu.author.split("@")[0]} telah memberhentikan @${num.split("@")[0]} sebagai admin grup`, 
contextInfo: {mentionedJid: [...tag], externalAdReply: { thumbnailUrl: ppuser, title: '© Demote Message', body: '', renderLargerThumbnail: true, sourceUrl: linkgc, mediaType: 1}}})
}
} 
} catch (err) {
console.log(err)
}})

vinzzoffc.ev.on('contacts.update', (update) => {
for (let contact of update) {
let id = vinzzoffc.decodeJid(contact.id)
if (store && store.contacts) store.contacts[id] = { id, name: contact.notify }
}
})

vinzzoffc.sendPoll = (jid, name = '', values = [], selectableCount = 1) => {
return vinzzoffc.sendMessage(jid, {poll: { name, values, selectableCount }})
};

vinzzoffc.ev.on('creds.update', saveCreds)
return vinzzoffc
}

console.log(chalk.green.bold(`
─[ 𝐕𝐈𝐍𝐙𝐙 - 𝐒𝐋𝐀𝐘𝐄𝐑 ]-\n𝙰𝚞𝚝𝚑𝚘𝚛 : 𝚅𝚒𝚗𝚣𝚣 (𝚖𝚎) \n𝚂𝚌𝚛𝚒𝚙𝚝 : 𝙿𝚛𝚒𝚟𝚊𝚝 (𝚙𝚛𝚒𝚋)\n𝚂𝚝𝚊𝚝𝚞𝚜 : 𝚝𝚛𝚞𝚎 (𝚊𝚌𝚝𝚒𝚟𝚎)\n\n${chalk.yellow.bold(`📃  Infomation : Push/Bug/Cpanel\n🤖  Vinzz-Slayer: (𝚗𝚊𝚖𝚎 𝚋𝚘𝚝)\n🔗  Version: 1.0.0\n💻  Author: Vinzz-Official`)}\n\n${chalk.blue.bold("📝  Pesan:\nbuy vps dan kebutuhan hosting\nlainnya silahkan hubungi vinz\n🪀  Whatsapp: 6285218951518\n🌐  Telegram: @VinzzOfficiall\n🌈  Instagram: @balerinakapucin4")}
`));
ConnetToWhatsapp()

process.on('uncaughtException', function (err) {
console.log('Caught exception: ', err)
})