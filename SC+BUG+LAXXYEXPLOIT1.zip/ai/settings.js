require("./system/module.js")

global.owner = ""
global.namabot = "LaxxyExploit" 
global.namaowner = "LaxxyExploit"
global.packname = "Laxxyoffc"
global.author = "LaxxyExploit"
global.antri = 5000
global.id = "120363401673252785@newsletter"
global.footer = ""
global.msg = {
wait: "Memproses . . .", 
owner: "Fitur ini khusus untuk owner!", 
group: "Fitur ini untuk dalam grup!", 
admin: "Fitur ini untuk admin grup!", 
botadmin: "Fitur ini hanya untuk bot menjadi admin"
}


let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.cyan("File Update => "), chalk.cyan.bgBlue.bold(`${__filename}`))
delete require.cache[file]
require(file)
})