global.prefa = ['','!','.',',','🐤','🗿']
global.owner = ['6288708844767']
global.gambar = ""
// GANTI NO OWNER DENGAN NOMOR MU LALU RUNN SEPERTI BIASA !!!