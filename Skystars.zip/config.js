module.exports = {
  BOT_TOKEN: "8317200381:AAGQDovoBzhda0gMjYgDowluLX94Wr4Dow0",
};